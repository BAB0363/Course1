import { useEffect, useRef } from "react";
import { Car, RotateCcw, Trophy, Users } from "lucide-react";
import { CARS, TEAMS, getTrack } from "@/game/data";
import { formatTime, teamWinnerOf } from "@/game/scoring";
import type { Player, RaceResult, SaveData, ScoredBet } from "@/game/types";

export function PodiumScreen({
  result,
  save,
  scored,
  onSetup,
  onRematch,
}: {
  result: RaceResult;
  save: SaveData;
  scored: ScoredBet[];
  onSetup: () => void;
  onRematch: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const champ = save.championship;
  const rows = [...result.rows].sort((a, b) => a.rank - b.rank);
  const first = rows[0];
  const second = rows[1];
  const third = rows[2];
  const steps = [
    { car: second, place: "2e", h: "h-24", pts: "+1 pt" },
    { car: first, place: "1er", h: "h-32", pts: "+3 pts" },
    { car: third, place: "3e", h: "h-20", pts: "Podium" },
  ];
  const board = [...scored].sort((a, b) => {
    const pa = save.players.find((p) => p.id === a.playerId)?.score ?? 0;
    const pb = save.players.find((p) => p.id === b.playerId)?.score ?? 0;
    return pb - pa;
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;
    const parent = canvas.parentElement;
    if (!parent) return;
    canvas.width = parent.clientWidth;
    canvas.height = parent.clientHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const colors = ["#ef4444", "#3b82f6", "#fbbf24", "#34d399", "#a855f7", "#f97316", "#f8fafc"];
    const pieces = Array.from({ length: 70 }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * -canvas.height,
      w: 6 + Math.random() * 6,
      h: 4 + Math.random() * 5,
      vy: 1.6 + Math.random() * 2.4,
      vx: (Math.random() - 0.5) * 1.4,
      a: Math.random() * Math.PI,
      va: (Math.random() - 0.5) * 0.1,
      color: colors[Math.floor(Math.random() * colors.length)] ?? "#fff",
    }));
    let frame = 0;
    const loop = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (const p of pieces) {
        p.x += p.vx;
        p.y += p.vy;
        p.a += p.va;
        if (p.y > canvas.height + 8) {
          p.y = -8;
          p.x = Math.random() * canvas.width;
        }
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.a);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        ctx.restore();
      }
      frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frame);
  }, []);

  return (
    <div className="relative flex h-full min-h-0 flex-col bg-void/95">
      <canvas ref={canvasRef} className="pointer-events-none absolute inset-0 h-full w-full" />
      <div className="thin-scroll relative z-10 flex-1 space-y-4 overflow-y-auto p-4">
        <div className="text-center">
          <p className="inline-flex items-center gap-1.5 rounded-full border border-gold/40 bg-gold/15 px-3 py-1 text-xs font-bold uppercase tracking-wide text-gold">
            <Trophy className="size-3.5" aria-hidden /> Arrivée officielle
          </p>
          <h2 className="mt-2 font-display text-2xl text-ink" style={{ color: first?.light }}>
            {result.mode === "timetrial" ? "Meilleur temps" : "Victoire"} de {first?.name ?? "—"}
          </h2>
          <p className="text-sm text-mist">
            {getTrack(result.trackId).name}
            {result.mode === "timetrial" && first?.finishTime != null ? ` · ${formatTime(first.finishTime)}` : ""}
            {result.scCount > 0 ? ` · ${result.scCount} Safety Car` : ""}
          </p>
          {result.mode === "teams" && (
            <p className="mt-1 font-display text-gold">{TEAMS[teamWinnerOf(result)].name}</p>
          )}
        </div>

        <div className="grid grid-cols-3 items-end gap-2 px-1">
          {steps.map((step) =>
            step.car ? (
              <div key={step.place} className="flex flex-col items-center">
                <div className="mb-2 grid size-12 place-items-center rounded-2xl border-2 border-ink/50" style={{ backgroundColor: step.car.hex }}>
                  <Car className="size-6 text-ink" aria-hidden />
                </div>
                <p className="text-center text-xs font-bold text-ink">{step.car.short}</p>
                <p className="mb-2 max-w-full truncate text-center text-xs text-gold">
                  {namesFor(save.players, step.car.id)}
                </p>
                <div className={`flex w-full ${step.h} flex-col items-center justify-between rounded-t-2xl bg-gold px-1 py-2 text-gold-ink`}>
                  <span className="font-display">{step.place}</span>
                  <span className="text-xs font-bold">{step.car.finishTime != null ? formatTime(step.car.finishTime) : step.pts}</span>
                </div>
              </div>
            ) : (
              <div key={step.place} />
            ),
          )}
        </div>

        <section className="rounded-2xl border border-lane bg-pit p-3">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="flex items-center gap-1.5 font-display text-sm text-gold">
              <Users className="size-4" aria-hidden /> Paris de la manche
            </h3>
            <span className="text-xs text-mist">Carrière</span>
          </div>
          {board.length === 0 ? (
            <p className="py-3 text-center text-sm text-mist">Aucun pari sur cette manche.</p>
          ) : (
            <ul className="space-y-2">
              {board.map((item, index) => {
                const player = save.players.find((p) => p.id === item.playerId);
                const car = CARS[player?.carId ?? 0];
                return (
                  <li key={item.playerId} className="flex items-center justify-between gap-2 rounded-xl border border-lane bg-asphalt px-2 py-2">
                    <div className="flex min-w-0 items-center gap-2">
                      <span className="w-5 text-xs text-mist">{index + 1}.</span>
                      <span className="size-3.5 rounded-full" style={{ backgroundColor: car?.hex }} />
                      <span className="truncate text-sm font-bold text-ink">{player?.name}</span>
                    </div>
                    <div className="flex shrink-0 items-center gap-1.5">
                      <span className={badgeClass(item.tone)}>{item.badge}</span>
                      <span className="rounded-lg border border-lane bg-pit px-2 py-0.5 font-display text-sm text-gold">
                        {player?.score ?? 0} pt{(player?.score ?? 0) > 1 ? "s" : ""}
                      </span>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        {champ && (
          <section className="rounded-2xl border border-lane bg-asphalt p-3">
            <h3 className="font-display text-sm text-gold">
              {champ.completed ? "Championnat terminé" : `Championnat · manche ${Math.min(champ.round, champ.rounds)}/${champ.rounds}`}
            </h3>
            <ol className="mt-2 space-y-1">
              {[...champ.standings]
                .sort((a, b) => b.points - a.points)
                .map((row, i) => (
                  <li key={row.playerId} className="flex justify-between text-sm">
                    <span className="text-ink">{i + 1}. {save.players.find((p) => p.id === row.playerId)?.name ?? "Joueur"}</span>
                    <span className="font-display text-gold">{row.points} pts</span>
                  </li>
                ))}
            </ol>
            {champ.completed && save.trophies.slice(0, 3).length > 0 && (
              <ul className="mt-3 space-y-1 text-sm text-ink">
                {save.trophies.slice(0, 3).map((t) => (
                  <li key={t.id}>{t.title} — {t.playerName}</li>
                ))}
              </ul>
            )}
          </section>
        )}

        <div className="space-y-2 pb-2">
          <button type="button" onClick={onSetup} className="btn-arcade press-go flex w-full items-center justify-center gap-2 rounded-2xl bg-go py-3.5 font-display text-lg text-go-ink">
            <Users className="size-5" aria-hidden />
            {champ && !champ.completed ? "Manche suivante" : "Nouvelle manche"}
          </button>
          {!champ && (
            <button type="button" onClick={onRematch} className="btn-arcade press-pit flex w-full items-center justify-center gap-2 rounded-xl border border-lane bg-asphalt py-3 font-display text-sm text-ink">
              <RotateCcw className="size-4" aria-hidden />
              Revanche, mêmes paris
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function namesFor(players: Player[], carId: number) {
  const names = players.filter((p) => p.carId === carId).map((p) => p.name);
  return names.length ? names.join(", ") : "Aucun pari";
}

function badgeClass(tone: ScoredBet["tone"]) {
  const base = "rounded-full border px-2 py-0.5 text-xs font-bold";
  if (tone === "gold") return `${base} border-gold/50 bg-gold/20 text-gold`;
  if (tone === "silver") return `${base} border-lane bg-pit text-ink`;
  if (tone === "bronze") return `${base} border-flare/40 bg-flare/15 text-flare`;
  if (tone === "team") return `${base} border-storm/40 bg-storm/15 text-storm`;
  return `${base} border-lane text-mist`;
}
