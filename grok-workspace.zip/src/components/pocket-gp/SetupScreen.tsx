import { useEffect, useRef, type ReactNode } from "react";
import {
  Car,
  CloudFog,
  CloudRain,
  Download,
  Flag,
  Maximize2,
  Minimize2,
  Plus,
  Route,
  Shield,
  ShieldOff,
  Shuffle,
  Smartphone,
  Sun,
  Trophy,
  Upload,
  Users,
  Volume2,
  VolumeX,
  Wind,
  X,
  Zap,
} from "lucide-react";
import { CARS, MODES, TEAMS, TRACKS, WEATHERS, getTrack } from "@/game/data";
import { drawMini } from "@/game/draw";
import { formatTime } from "@/game/scoring";
import type { Player, SaveData } from "@/game/types";

export function SetupScreen({
  save,
  offline,
  fullscreen,
  installReady,
  toast,
  onPatch,
  onStart,
  onCreateChamp,
  onAbandonChamp,
  onExport,
  onImport,
  onReset,
  onSound,
  onFullscreen,
  onInstall,
  onToast,
}: {
  save: SaveData;
  offline: boolean;
  fullscreen: boolean;
  installReady: boolean;
  toast: string | null;
  onPatch: (partial: Partial<SaveData>) => void;
  onStart: () => void;
  onCreateChamp: (rounds: number) => void;
  onAbandonChamp: () => void;
  onExport: () => void;
  onImport: (file: File) => void;
  onReset: () => void;
  onSound: () => void;
  onFullscreen: () => void;
  onInstall: () => void;
  onToast: (message: string) => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const miniRef = useRef<HTMLCanvasElement>(null);
  const champ = save.championship;
  const locked = !!champ && !champ.completed;
  const track = getTrack(locked ? (champ.trackIds[champ.round] ?? save.trackId) : save.trackId);
  const mode = locked ? champ.mode : save.mode;
  const record = save.records[track.id];

  useEffect(() => {
    if (miniRef.current) drawMini(miniRef.current, track);
  }, [track]);

  function setCars(count: number) {
    const selected = save.selectedCar >= count ? 0 : save.selectedCar;
    const players = save.players.map((p) => ({ ...p, carId: p.carId % count }));
    onPatch({ carCount: count, selectedCar: selected, players });
  }

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="flex items-center justify-between gap-2 border-b border-lane px-3 py-3">
        <div className="flex items-center gap-2.5">
          <div className="grid size-11 place-items-center rounded-xl border border-ink/20 bg-flare text-ink">
            <Flag className="size-5" aria-hidden />
          </div>
          <div>
            <h1 className="font-display text-xl leading-none text-ink">
              POCKET <span className="text-gold">GP</span>
            </h1>
            <p className="text-xs text-mist">Courses, paris, championnats</p>
          </div>
        </div>
        <div className="flex gap-1.5">
          <IconBtn label={fullscreen ? "Quitter le plein écran" : "Plein écran"} onClick={onFullscreen}>
            {fullscreen ? <Minimize2 className="size-4" /> : <Maximize2 className="size-4" />}
          </IconBtn>
          <IconBtn label="Installer sur l'écran d'accueil" onClick={onInstall}>
            <Smartphone className={`size-4 ${installReady ? "text-go" : ""}`} />
          </IconBtn>
          <IconBtn label={save.sound ? "Couper le son" : "Activer le son"} onClick={onSound}>
            {save.sound ? <Volume2 className="size-4 text-go" /> : <VolumeX className="size-4" />}
          </IconBtn>
        </div>
      </header>

      <div className="thin-scroll flex-1 space-y-3 overflow-y-auto p-3">
        {offline && (
          <p className="rounded-xl border border-lane bg-asphalt px-3 py-2 text-xs text-mist">
            Hors ligne — la course, les scores et l'installation restent disponibles sur cet appareil.
          </p>
        )}

        <section className="rounded-2xl border border-lane bg-asphalt p-3">
          <p className="mb-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-gold">
            <Flag className="size-3.5" aria-hidden /> Mode
          </p>
          <div className="grid grid-cols-2 gap-2">
            {MODES.map((item) => (
              <button
                key={item.id}
                type="button"
                disabled={locked}
                onClick={() => onPatch({ mode: item.id, safetyCar: item.id === "timetrial" ? false : save.safetyCar })}
                className={chip(mode === item.id)}
              >
                {item.label}
              </button>
            ))}
          </div>
          <p className="mt-2 text-xs text-mist">{MODES.find((m) => m.id === mode)?.hint}</p>
          {mode === "elimination" && save.lapCount < save.carCount - 1 && (
            <p className="mt-1 text-xs text-gold">Pour un vainqueur unique, vise au moins {save.carCount - 1} tours.</p>
          )}
        </section>

        <section className="rounded-2xl border border-lane bg-asphalt p-3">
          <p className="mb-2 text-xs font-bold uppercase tracking-wide text-gold">Météo et safety car</p>
          <div className="grid grid-cols-5 gap-1.5">
            {WEATHERS.map((w) => (
              <button key={w.id} type="button" disabled={locked} onClick={() => onPatch({ weather: w.id })} className={`${chip((locked ? champ.weather : save.weather) === w.id)} flex flex-col items-center justify-center px-0.5 text-center leading-none`}>
                <WeatherIcon id={w.id} />
                <span className="mt-0.5 block text-xs">{w.label}</span>
              </button>
            ))}
          </div>
          <button
            type="button"
            disabled={locked || mode === "timetrial"}
            onClick={() => onPatch({ safetyCar: !save.safetyCar })}
            className="mt-2 flex min-h-11 w-full items-center justify-center gap-2 rounded-xl border border-lane bg-pit text-sm font-semibold text-ink"
          >
            {(locked ? champ.safetyCar : save.safetyCar) && mode !== "timetrial" ? <Shield className="size-4 text-gold" /> : <ShieldOff className="size-4 text-mist" />}
            Safety Car {(locked ? champ.safetyCar : save.safetyCar) && mode !== "timetrial" ? "active" : "coupée"}
          </button>
          <p className="mt-2 text-xs text-mist">Pluie : moins d'adhérence. Brouillard : visibilité. Vent : les voitures dérivent.</p>
        </section>

        <section className="rounded-2xl border border-lane bg-asphalt p-3">
          <div className="mb-2 flex items-center justify-between gap-2">
            <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-gold">
              <Route className="size-3.5" aria-hidden /> Circuit
            </p>
            <span className="rounded-full border border-lane px-2 py-0.5 text-xs text-mist">{track.badge}</span>
          </div>
          <div className="flex gap-3">
            <div className="h-28 w-24 shrink-0 overflow-hidden rounded-xl border-2 border-lane">
              <canvas ref={miniRef} className="h-full w-full" />
            </div>
            <div className="min-w-0 flex-1">
              <h2 className="font-display text-lg leading-tight text-ink">{track.name}</h2>
              <p className="text-xs text-mist">{track.night ? "Éclairage nocturne" : "Jour"}{track.sections.length ? ` · ${track.sections.map((s) => (s.kind === "tunnel" ? "tunnel" : "pont")).join(" + ")}` : ""}</p>
              {record && (
                <p className="mt-1 text-xs text-gold">Record {formatTime(record.ms / 1000)} · {record.holder}</p>
              )}
            </div>
          </div>
          <div className="mt-2 flex gap-1.5 overflow-x-auto pb-1">
            {TRACKS.map((item) => (
              <button
                key={item.id}
                type="button"
                disabled={locked}
                onClick={() => onPatch({ trackId: item.id })}
                className={`shrink-0 rounded-full border px-3 py-2 text-xs font-semibold ${item.id === track.id ? "border-gold bg-gold text-gold-ink" : "border-lane bg-pit text-ink"}`}
              >
                {item.name}
              </button>
            ))}
          </div>
          {locked && <p className="text-xs text-gold">Circuit imposé par le championnat.</p>}
        </section>

        <section className="grid grid-cols-2 gap-2">
          <div className="rounded-2xl border border-lane bg-asphalt p-3">
            <p className="mb-2 flex items-center gap-1 text-xs font-bold uppercase tracking-wide text-gold"><Car className="size-3.5" /> Voitures</p>
            <div className="grid grid-cols-4 gap-1">
              {[3, 4, 5, 6].map((n) => (
                <button key={n} type="button" disabled={locked} onClick={() => setCars(n)} className={chip((locked ? champ.carCount : save.carCount) === n)}>{n}</button>
              ))}
            </div>
          </div>
          <div className="rounded-2xl border border-lane bg-asphalt p-3">
            <p className="mb-2 text-xs font-bold uppercase tracking-wide text-gold">Tours</p>
            <div className="grid grid-cols-4 gap-1">
              {[2, 3, 5, 8].map((n) => (
                <button key={n} type="button" disabled={locked} onClick={() => onPatch({ lapCount: n })} className={chip((locked ? champ.lapCount : save.lapCount) === n)}>{n}</button>
              ))}
            </div>
          </div>
        </section>

        <section className="rounded-2xl border border-lane bg-asphalt p-3">
          <p className="mb-1 text-xs font-bold uppercase tracking-wide text-gold">Zones sur la piste</p>
          <div className="grid grid-cols-4 gap-1 text-center text-xs text-mist">
            <span><Zap className="mx-auto size-4 text-gold" aria-hidden />Boost</span>
            <span><span className="mx-auto mb-0.5 block size-3 rounded-full bg-mist" />Gravier</span>
            <span><span className="mx-auto mb-0.5 block h-3 w-5 rounded-full bg-pit" />Huile</span>
            <span><span className="mx-auto mb-0.5 block h-0 w-0 border-x-8 border-b-8 border-x-transparent border-b-ink" />Saut</span>
          </div>
        </section>

        <ChampionshipCard
          save={save}
          onCreate={onCreateChamp}
          onAbandon={onAbandonChamp}
          onDismiss={() => onAbandonChamp()}
        />

        <section className="rounded-2xl border border-lane bg-asphalt p-3">
          <div className="mb-2 flex items-center justify-between">
            <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-gold">
              <Users className="size-3.5" aria-hidden /> Paris
            </p>
            <span className="text-xs text-mist">1er +3 · 2e +1</span>
          </div>
          <PlayerForm save={save} onPatch={onPatch} onToast={onToast} />
          <ul className="mt-2 space-y-1.5">
            {save.players.length === 0 && (
              <li className="rounded-xl border border-dashed border-lane px-3 py-4 text-center text-xs text-mist">
                Aucun parieur. Tu peux quand même lancer la course.
              </li>
            )}
            {save.players.map((player) => {
              const car = CARS[player.carId] ?? CARS[0];
              return (
                <li key={player.id} className="flex items-center justify-between gap-2 rounded-xl border border-lane bg-pit px-2 py-1.5">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-ink">{player.name}</p>
                    <p className="text-xs text-gold">{player.score} pt{player.score > 1 ? "s" : ""} · {player.wins} victoire{player.wins > 1 ? "s" : ""}</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => cycleCar(player, save, onPatch)}
                      className="flex min-h-11 items-center gap-1 rounded-lg border border-ink/30 px-2 text-xs font-bold text-ink"
                      style={{ backgroundColor: car.hex }}
                    >
                      <Car className="size-3.5" aria-hidden />
                      {car.short}
                      {mode === "teams" ? ` · ${TEAMS[player.carId % 2].short}` : ""}
                    </button>
                    <button type="button" aria-label={`Retirer ${player.name}`} onClick={() => onPatch({ players: save.players.filter((p) => p.id !== player.id) })} className="grid size-11 place-items-center rounded-lg text-mist">
                      <X className="size-4" />
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>

        <section className="rounded-2xl border border-lane bg-asphalt p-3">
          <p className="mb-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-gold">
            <Trophy className="size-3.5" aria-hidden /> Classement local
          </p>
          <ol className="space-y-1">
            {[...save.players].sort((a, b) => b.score - a.score || b.wins - a.wins).slice(0, 8).map((p, i) => (
              <li key={p.id} className="flex justify-between text-sm">
                <span className="text-ink">{i + 1}. {p.name}</span>
                <span className="text-mist">{p.score} pts · {p.podiums} podiums</span>
              </li>
            ))}
            {save.players.length === 0 && <li className="text-sm text-mist">Les points restent sur cet appareil.</li>}
          </ol>
          {save.trophies.length > 0 && (
            <ul className="mt-2 space-y-1 border-t border-lane pt-2 text-xs text-ink">
              {save.trophies.slice(0, 4).map((t) => (
                <li key={t.id}>{t.title} — {t.playerName}</li>
              ))}
            </ul>
          )}
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button type="button" onClick={onExport} className="flex min-h-11 items-center justify-center gap-1 rounded-xl border border-lane bg-pit text-sm text-ink">
              <Download className="size-4" aria-hidden /> Exporter
            </button>
            <button type="button" onClick={() => fileRef.current?.click()} className="flex min-h-11 items-center justify-center gap-1 rounded-xl border border-lane bg-pit text-sm text-ink">
              <Upload className="size-4" aria-hidden /> Importer
            </button>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) onImport(file);
              e.target.value = "";
            }}
          />
          <button type="button" onClick={onReset} className="mt-2 min-h-11 w-full rounded-xl text-xs text-mist">
            Remettre les points à zéro
          </button>
        </section>
      </div>

      {toast && <p className="mx-3 mb-2 rounded-xl bg-gold px-3 py-2 text-center text-xs font-bold text-gold-ink">{toast}</p>}

      <div className="shrink-0 border-t border-lane p-3">
        <button type="button" onClick={onStart} className="btn-arcade press-flare flex w-full items-center justify-center gap-2 rounded-2xl bg-flare py-3.5 font-display text-xl text-ink">
          <Flag className="size-5" aria-hidden />
          {locked ? `Manche ${champ.round + 1}/${champ.rounds}` : "Lancer la course"}
        </button>
      </div>
    </div>
  );
}

function ChampionshipCard({
  save,
  onCreate,
  onAbandon,
  onDismiss,
}: {
  save: SaveData;
  onCreate: (rounds: number) => void;
  onAbandon: () => void;
  onDismiss: () => void;
}) {
  const champ = save.championship;
  if (champ?.completed) {
    return (
      <section className="rounded-2xl border border-gold/40 bg-asphalt p-3">
        <p className="font-display text-gold">Trophées décernés</p>
        <p className="mt-1 text-sm text-ink">{save.trophies[0] ? `${save.trophies[0].title} : ${save.trophies[0].playerName}` : "Saison bouclée."}</p>
        <button type="button" onClick={onDismiss} className="btn-arcade press-gold mt-2 min-h-11 w-full rounded-xl bg-gold font-display text-gold-ink">Ranger la saison</button>
      </section>
    );
  }
  if (champ) {
    const next = getTrack(champ.trackIds[champ.round] ?? champ.trackIds[0]);
    const board = [...champ.standings].sort((a, b) => b.points - a.points);
    return (
      <section className="rounded-2xl border border-gold/40 bg-asphalt p-3">
        <p className="font-display text-gold">Championnat {champ.round + 1}/{champ.rounds}</p>
        <p className="text-sm text-ink">Prochain : {next.name}</p>
        <ol className="mt-2 space-y-1">
          {board.map((row, i) => (
            <li key={row.playerId} className="flex justify-between text-sm">
              <span>{i + 1}. {save.players.find((p) => p.id === row.playerId)?.name ?? "Joueur"}</span>
              <span className="text-gold">{row.points} pts</span>
            </li>
          ))}
        </ol>
        <button type="button" onClick={onAbandon} className="mt-2 text-xs text-mist">Abandonner le championnat</button>
      </section>
    );
  }
  return (
    <section className="rounded-2xl border border-lane bg-asphalt p-3">
      <p className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-gold">
        <Trophy className="size-3.5" aria-hidden /> Championnat
      </p>
      <p className="mt-1 text-xs text-mist">Plusieurs manches, points cumulés, trophée à la fin. Les circuits tournent à partir de celui choisi.</p>
      <div className="mt-2 grid grid-cols-3 gap-2">
        {[3, 5, 8].map((n) => (
          <button key={n} type="button" onClick={() => onCreate(n)} className="btn-arcade press-pit min-h-11 rounded-xl border border-lane bg-pit font-display text-sm text-ink">
            {n} manches
          </button>
        ))}
      </div>
    </section>
  );
}

function PlayerForm({ save, onPatch, onToast }: { save: SaveData; onPatch: (partial: Partial<SaveData>) => void; onToast: (message: string) => void }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const count = save.championship && !save.championship.completed ? save.championship.carCount : save.carCount;

  function add(nameRaw?: string) {
    const name = (nameRaw ?? inputRef.current?.value ?? "").trim().slice(0, 14);
    if (!name) {
      onToast("Entre le prénom du joueur avant de valider son pari.");
      inputRef.current?.focus();
      return;
    }
    const player: Player = { id: save.nextPlayerId, name, carId: save.selectedCar % count, score: 0, wins: 0, podiums: 0 };
    onPatch({
      players: [...save.players, player],
      nextPlayerId: save.nextPlayerId + 1,
      selectedCar: (save.selectedCar + 1) % count,
    });
    if (inputRef.current) inputRef.current.value = "";
  }

  return (
    <div className="rounded-xl border border-lane bg-pit p-2">
      <div className="flex gap-2">
        <input
          ref={inputRef}
          maxLength={14}
          placeholder="Prénom du parieur"
          aria-label="Prénom du parieur"
          className="min-h-11 flex-1 rounded-lg border border-lane bg-asphalt px-3 text-sm text-ink outline-none"
          onKeyDown={(e) => {
            if (e.key === "Enter") add();
          }}
        />
        <button type="button" onClick={() => add()} className="btn-arcade press-go flex min-h-11 items-center gap-1 rounded-lg bg-go px-3 font-display text-sm text-go-ink">
          <Plus className="size-4" aria-hidden /> Parier
        </button>
      </div>
      <div className="mt-2 grid grid-cols-6 gap-1.5">
        {CARS.slice(0, count).map((car) => {
          const on = car.id === save.selectedCar % count;
          return (
            <button
              key={car.id}
              type="button"
              aria-label={car.name}
              onClick={() => onPatch({ selectedCar: car.id })}
              className={`grid h-11 place-items-center rounded-lg border-2 ${on ? "border-ink" : "border-transparent opacity-80"}`}
              style={{ backgroundColor: car.hex }}
            >
              <Car className="size-4 text-ink" />
            </button>
          );
        })}
      </div>
      <p className="mt-1 text-xs text-mist">Voiture : <span className="font-bold text-ink">{CARS[save.selectedCar % count]?.name}</span></p>
    </div>
  );
}

function cycleCar(player: Player, save: SaveData, onPatch: (partial: Partial<SaveData>) => void) {
  const count = save.championship && !save.championship.completed ? save.championship.carCount : save.carCount;
  onPatch({
    players: save.players.map((p) => (p.id === player.id ? { ...p, carId: (p.carId + 1) % count } : p)),
  });
}

function chip(on: boolean) {
  return `min-h-11 rounded-xl border px-2 font-display text-sm ${on ? "border-gold bg-gold text-gold-ink" : "border-lane bg-pit text-ink"}`;
}

function IconBtn({ children, label, onClick }: { children: ReactNode; label: string; onClick: () => void }) {
  return (
    <button type="button" aria-label={label} onClick={onClick} className="grid size-11 place-items-center rounded-xl border border-lane bg-asphalt text-ink">
      {children}
    </button>
  );
}

function WeatherIcon({ id }: { id: string }) {
  const cls = "mx-auto size-4";
  if (id === "rain") return <CloudRain className={cls} aria-hidden />;
  if (id === "fog") return <CloudFog className={cls} aria-hidden />;
  if (id === "wind") return <Wind className={cls} aria-hidden />;
  if (id === "random") return <Shuffle className={cls} aria-hidden />;
  return <Sun className={cls} aria-hidden />;
}
