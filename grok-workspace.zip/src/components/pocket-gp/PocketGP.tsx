import { useEffect, useRef, useState } from "react";
import { X } from "lucide-react";
import { setSoundEnabled, unlockAudio } from "@/game/audio";
import { scoreRace } from "@/game/scoring";
import { applyRace, createChampionship, downloadSave, loadSave, parseSave, persistSave, zeroScores } from "@/game/storage";
import type { RaceConfig, RaceResult, SaveData, ScoredBet } from "@/game/types";
import { PodiumScreen } from "./PodiumScreen";
import { RaceScreen } from "./RaceScreen";
import { SetupScreen } from "./SetupScreen";

type BeforeInstall = Event & { prompt: () => Promise<void> };

export function PocketGP() {
  const [save, setSave] = useState<SaveData | null>(null);
  const [view, setView] = useState<"setup" | "race" | "podium">("setup");
  const [config, setConfig] = useState<RaceConfig | null>(null);
  const [result, setResult] = useState<RaceResult | null>(null);
  const [scored, setScored] = useState<ScoredBet[]>([]);
  const [nonce, setNonce] = useState(0);
  const [toast, setToast] = useState<string | null>(null);
  const [offline, setOffline] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [installReady, setInstallReady] = useState(false);
  const [help, setHelp] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const shellRef = useRef<HTMLDivElement>(null);
  const installEvent = useRef<BeforeInstall | null>(null);
  const toastTimer = useRef<number>(0);

  useEffect(() => {
    const loaded = loadSave();
    setSave(loaded);
    setSoundEnabled(loaded.sound);
    const sync = () => setOffline(!navigator.onLine);
    sync();
    window.addEventListener("online", sync);
    window.addEventListener("offline", sync);
    const onFs = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    const onPrompt = (event: Event) => {
      event.preventDefault();
      installEvent.current = event as BeforeInstall;
      setInstallReady(true);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    if (import.meta.env.PROD && "serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {});
    }
    return () => {
      window.removeEventListener("online", sync);
      window.removeEventListener("offline", sync);
      document.removeEventListener("fullscreenchange", onFs);
      window.removeEventListener("beforeinstallprompt", onPrompt);
    };
  }, []);

  function ping(message: string) {
    setToast(message);
    window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 2600);
  }

  function commit(next: SaveData) {
    setSave(next);
    persistSave(next);
    setSoundEnabled(next.sound);
  }

  function patch(partial: Partial<SaveData>) {
    if (!save) return;
    unlockAudio();
    commit({ ...save, ...partial });
  }

  function startRace(from?: RaceConfig) {
    if (!save) return;
    unlockAudio();
    const champ = save.championship;
    const locked = !!champ && !champ.completed;
    const next: RaceConfig = from ?? {
      trackId: locked ? (champ.trackIds[champ.round] ?? save.trackId) : save.trackId,
      mode: locked ? champ.mode : save.mode,
      weather: locked ? champ.weather : save.weather,
      carCount: locked ? champ.carCount : save.carCount,
      lapCount: locked ? champ.lapCount : save.lapCount,
      safetyCar: (locked ? champ.mode : save.mode) === "timetrial" ? false : locked ? champ.safetyCar : save.safetyCar,
      players: save.players,
    };
    setConfig(next);
    setNonce((n) => n + 1);
    setView("race");
  }

  function onFinish(raceResult: RaceResult) {
    if (!save) return;
    setScored(scoreRace(raceResult, save.players));
    setResult(raceResult);
    commit(applyRace(save, raceResult));
    setView("podium");
  }

  async function toggleFullscreen() {
    const shell = shellRef.current;
    if (!shell) return;
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await shell.requestFullscreen();
    } catch {
      setHelp(true);
    }
  }

  async function install() {
    if (installEvent.current) {
      await installEvent.current.prompt();
      installEvent.current = null;
      setInstallReady(false);
      return;
    }
    setHelp(true);
  }

  if (!save) {
    return (
      <main className="grid h-dvh place-items-center bg-void text-ink">
        <p className="font-display text-2xl">Pocket GP</p>
      </main>
    );
  }

  return (
    <main className="grid h-dvh place-items-center bg-void text-ink">
      <div
        ref={shellRef}
        className={`phone-shell relative flex flex-col overflow-hidden bg-pit shadow-2xl ${fullscreen ? "is-full" : ""}`}
      >
        <div className="curb" />
        <div className="min-h-0 flex-1">
          {view === "setup" && (
            <SetupScreen
              save={save}
              offline={offline}
              fullscreen={fullscreen}
              installReady={installReady}
              toast={toast}
              onPatch={patch}
              onStart={() => startRace()}
              onCreateChamp={(rounds) => {
                unlockAudio();
                commit(createChampionship(save, rounds));
                ping(`Championnat ${rounds} manches créé`);
              }}
              onAbandonChamp={() => {
                commit({ ...save, championship: null });
                ping("Championnat rangé");
              }}
              onExport={() => downloadSave(save)}
              onImport={(file) => {
                file.text().then((text) => {
                  const parsed = parseSave(text);
                  if (!parsed) {
                    ping("Fichier de session invalide");
                    return;
                  }
                  commit(parsed);
                  ping("Session importée");
                }).catch(() => ping("Lecture impossible"));
              }}
              onReset={() => setConfirmReset(true)}
              onSound={() => {
                unlockAudio();
                commit({ ...save, sound: !save.sound });
              }}
              onFullscreen={() => void toggleFullscreen()}
              onInstall={() => void install()}
              onToast={ping}
            />
          )}
          {view === "race" && config && (
            <RaceScreen
              key={nonce}
              config={config}
              onExit={() => setView("setup")}
              onRestart={() => startRace(config)}
              onFinish={onFinish}
            />
          )}
          {view === "podium" && result && (
            <PodiumScreen
              result={result}
              save={save}
              scored={scored}
              onSetup={() => setView("setup")}
              onRematch={() => config && startRace(config)}
            />
          )}
        </div>
        <div className="curb" />
        {help && (
          <div className="absolute inset-0 z-50 flex items-end bg-void/70 p-4 sm:items-center sm:justify-center" role="dialog" aria-modal="true" aria-labelledby="install-title">
            <div className="w-full max-w-sm rounded-3xl border border-lane bg-asphalt p-4">
              <div className="flex items-start justify-between gap-3">
                <h2 id="install-title" className="font-display text-xl text-ink">Installer Pocket GP</h2>
                <button type="button" aria-label="Fermer" onClick={() => setHelp(false)} className="grid size-11 place-items-center text-mist"><X /></button>
              </div>
              <p className="mt-2 text-sm text-mist">Le jeu fonctionne sans réseau une fois ouvert. Ajoute-le à l'écran d'accueil pour le lancer en plein écran.</p>
              <ul className="mt-3 space-y-2 text-sm text-ink">
                <li>Android : menu du navigateur, puis Installer l'application.</li>
                <li>iPhone : Partager, puis Sur l'écran d'accueil.</li>
                <li>Ordinateur : icône d'installation dans la barre d'adresse, ou le bouton plein écran.</li>
              </ul>
              <button type="button" onClick={() => setHelp(false)} className="btn-arcade press-gold mt-4 min-h-11 w-full rounded-xl bg-gold font-display text-gold-ink">Compris</button>
            </div>
          </div>
        )}
        {confirmReset && (
          <div className="absolute inset-0 z-50 flex items-center justify-center bg-void/70 p-4" role="dialog" aria-modal="true">
            <div className="w-full max-w-sm rounded-3xl border border-lane bg-asphalt p-4">
              <h2 className="font-display text-xl">Effacer les points ?</h2>
              <p className="mt-2 text-sm text-mist">Les prénoms restent. Le championnat en cours est abandonné. Les trophées déjà gagnés restent.</p>
              <div className="mt-4 grid grid-cols-2 gap-2">
                <button type="button" onClick={() => setConfirmReset(false)} className="min-h-11 rounded-xl border border-lane">Annuler</button>
                <button type="button" onClick={() => { commit(zeroScores(save)); setConfirmReset(false); ping("Points remis à zéro"); }} className="btn-arcade press-flare min-h-11 rounded-xl bg-flare font-display text-ink">Effacer</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
