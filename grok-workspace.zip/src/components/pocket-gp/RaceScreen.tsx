import { useEffect, useRef, useState } from "react";
import { Flag, Gauge, Pause, Play, RotateCcw, Settings, Shield } from "lucide-react";
import { getTrack, MODES, TEAMS } from "@/game/data";
import { drawWorld } from "@/game/draw";
import { playCountdown, playEvent, unlockAudio } from "@/game/audio";
import { formatTime } from "@/game/scoring";
import { RaceSim, type HudSnap } from "@/game/sim";
import type { RaceConfig, RaceResult } from "@/game/types";

const WEATHER_LABEL = { clear: "Clair", rain: "Pluie", fog: "Brouillard", wind: "Vent" } as const;

export function RaceScreen({
  config,
  onExit,
  onRestart,
  onFinish,
}: {
  config: RaceConfig;
  onExit: () => void;
  onRestart: () => void;
  onFinish: (result: RaceResult) => void;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const simRef = useRef<RaceSim | null>(null);
  const finishRef = useRef(onFinish);
  finishRef.current = onFinish;
  const [hud, setHud] = useState<HudSnap | null>(null);
  const [lights, setLights] = useState(0);
  const [countText, setCountText] = useState("PRÊTS...");
  const [showLights, setShowLights] = useState(true);
  const [paused, setPaused] = useState(false);
  const [speed, setSpeed] = useState<1 | 2>(1);
  const track = getTrack(config.trackId);
  const modeLabel = MODES.find((m) => m.id === config.mode)?.label ?? "Course";

  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    let dead = false;
    let raf = 0;
    const timers: number[] = [];
    const done = { current: false };

    const boot = () => {
      if (dead) return;
      const rect = wrap.getBoundingClientRect();
      if (rect.width < 30 || rect.height < 30) {
        raf = requestAnimationFrame(boot);
        return;
      }
      const sim = new RaceSim(
        getTrack(config.trackId),
        config.mode,
        config.weather,
        config.carCount,
        config.lapCount,
        config.safetyCar,
        config.players,
        rect.width,
        rect.height,
      );
      simRef.current = sim;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      const paint = () => {
        const live = simRef.current;
        if (!live) return;
        const box = wrap.getBoundingClientRect();
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        const bw = Math.max(1, Math.floor(box.width * dpr));
        const bh = Math.max(1, Math.floor(box.height * dpr));
        if (canvas.width !== bw || canvas.height !== bh) {
          canvas.width = bw;
          canvas.height = bh;
          live.resize(box.width, box.height);
        }
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        drawWorld(ctx, live, box.width, box.height);
      };

      let last = performance.now();
      const frame = (now: number) => {
        if (dead) return;
        const live = simRef.current;
        if (!live) return;
        const dt = Math.min(0.05, (now - last) / 1000);
        last = now;
        if (live.status === "racing") {
          live.update(dt);
          for (const ev of live.consumeEvents()) playEvent(ev);
        }
        paint();
        if (live.status === "finished" && !done.current) {
          done.current = true;
          finishRef.current(live.result());
        }
        raf = requestAnimationFrame(frame);
      };
      paint();
      raf = requestAnimationFrame(frame);
      timers.push(window.setTimeout(() => { setLights(1); setCountText("3"); playCountdown(false); }, 300));
      timers.push(window.setTimeout(() => { setLights(2); setCountText("2"); playCountdown(false); }, 1050));
      timers.push(window.setTimeout(() => { setLights(3); setCountText("1"); playCountdown(false); }, 1800));
      timers.push(window.setTimeout(() => {
        setLights(4);
        setCountText("GO !");
        playCountdown(true);
        sim.greenFlag();
      }, 2550));
      timers.push(window.setTimeout(() => setShowLights(false), 3400));
    };

    boot();
    const hudTimer = window.setInterval(() => {
      if (simRef.current) setHud(simRef.current.hud());
    }, 160);
    return () => {
      dead = true;
      cancelAnimationFrame(raf);
      timers.forEach((id) => clearTimeout(id));
      clearInterval(hudTimer);
    };
  }, [config]);

  function togglePause() {
    const sim = simRef.current;
    if (!sim) return;
    if (sim.status === "racing") {
      sim.status = "paused";
      setPaused(true);
    } else if (sim.status === "paused") {
      sim.status = "racing";
      setPaused(false);
    }
  }

  function toggleSpeed() {
    const sim = simRef.current;
    if (!sim) return;
    const next = sim.speedMult === 1 ? 2 : 1;
    sim.speedMult = next;
    setSpeed(next);
  }

  const lightClass = (index: number) => {
    if (lights >= 4) return "bulb-go";
    if (lights >= index) return "bulb-red";
    return "bulb";
  };

  return (
    <div className="flex h-full min-h-0 flex-col bg-pit">
      <div className="shrink-0 border-b border-lane bg-pit px-3 py-2">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1 rounded-lg bg-gold px-2 py-1 font-display text-xs text-gold-ink">
                <Flag className="size-3.5" aria-hidden />
                {hud?.lap ?? `TOUR 1 / ${config.lapCount}`}
              </span>
              {config.mode === "timetrial" && (
                <span className="font-display text-sm text-ink">{formatTime(hud?.clock ?? 0)}</span>
              )}
            </div>
            <p className="mt-1 truncate text-xs text-mist">
              {track.name} · {modeLabel} · {WEATHER_LABEL[hud?.weather ?? "clear"]}
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-1.5">
            <button type="button" onClick={toggleSpeed} className={`btn-arcade grid h-11 min-w-11 place-items-center rounded-xl border px-2 font-display text-sm ${speed === 2 ? "border-gold bg-gold text-gold-ink" : "border-lane bg-asphalt text-storm"}`} aria-label="Vitesse de course">
              <span className="inline-flex items-center gap-1"><Gauge className="size-3.5" aria-hidden />x{speed}</span>
            </button>
            <button type="button" onClick={togglePause} className="btn-arcade grid size-11 place-items-center rounded-xl border border-lane bg-asphalt text-gold" aria-label={paused ? "Reprendre" : "Pause"}>
              {paused ? <Play className="size-4" /> : <Pause className="size-4" />}
            </button>
            <button type="button" onClick={() => { unlockAudio(); onRestart(); }} className="btn-arcade grid size-11 place-items-center rounded-xl border border-lane bg-asphalt text-go" aria-label="Relancer le départ">
              <RotateCcw className="size-4" />
            </button>
            <button type="button" onClick={onExit} className="btn-arcade grid size-11 place-items-center rounded-xl border border-lane bg-asphalt text-flare" aria-label="Retour aux réglages">
              <Settings className="size-4" />
            </button>
          </div>
        </div>
        {hud?.teamBest && (
          <p className="mt-1 text-xs text-mist">
            Soleil meilleur {hud.teamBest[0] === 1 ? "1er" : `${hud.teamBest[0]}e`} · Orage meilleur {hud.teamBest[1] === 1 ? "1er" : `${hud.teamBest[1]}e`}
          </p>
        )}
        {config.mode === "elimination" && hud && (
          <p className="mt-1 text-xs text-gold">{hud.alive} voiture{hud.alive > 1 ? "s" : ""} encore en course</p>
        )}
        <div className="mt-2 grid grid-cols-2 gap-1.5">
          {(hud?.rows ?? []).map((row) => (
            <div key={row.rank} className="flex min-w-0 items-center gap-1.5 rounded-lg border border-lane bg-asphalt px-2 py-1">
              <span className={`w-7 shrink-0 font-display text-xs ${row.rank === 1 ? "text-gold" : "text-mist"}`}>
                {row.rank === 1 ? "1er" : `${row.rank}e`}
              </span>
              <span className="size-3 shrink-0 rounded-full border border-ink/40" style={{ backgroundColor: row.hex }} />
              <span className="truncate text-xs font-semibold text-ink">{row.label}</span>
              {config.mode === "teams" && (
                <span className={`ml-auto shrink-0 text-xs ${row.team === 0 ? "text-gold" : "text-storm"}`}>{TEAMS[row.team].short.slice(0, 1)}</span>
              )}
            </div>
          ))}
        </div>
      </div>

      <div ref={wrapRef} className="relative min-h-0 flex-1">
        <canvas ref={canvasRef} className="block h-full w-full touch-none" />
        {hud?.scReason && (
          <div className="pointer-events-none absolute inset-x-3 top-3 z-20 flex justify-center">
            <div className="flex items-center gap-2 rounded-full border border-gold bg-pit/95 px-3 py-1.5 text-xs font-bold text-gold">
              <Shield className="size-3.5" aria-hidden />
              Safety Car · {hud.scReason}
            </div>
          </div>
        )}
        {hud?.ticker && !hud.scReason && (
          <div className="pointer-events-none absolute inset-x-3 bottom-3 z-20 flex justify-center">
            <div className="rounded-full border border-lane bg-pit/90 px-3 py-1.5 text-xs font-bold text-ink">{hud.ticker.text}</div>
          </div>
        )}
        {showLights && (
          <div className="pointer-events-none absolute inset-x-0 top-8 z-30 flex justify-center">
            <div className="flex flex-col items-center gap-2 rounded-2xl border-2 border-lane bg-pit/95 px-5 py-3">
              <div className="flex gap-3">
                {[1, 2, 3].map((n) => (
                  <span key={n} className={`size-8 rounded-full border-4 border-void ${lightClass(n)}`} />
                ))}
              </div>
              <p className="font-display text-2xl text-ink">{countText}</p>
            </div>
          </div>
        )}
        {paused && (
          <div className="absolute inset-0 z-30 flex items-center justify-center bg-void/80 p-6">
            <div className="w-full max-w-xs space-y-3 rounded-3xl border-2 border-lane bg-pit p-5 text-center">
              <h2 className="font-display text-2xl text-ink">Course en pause</h2>
              <button type="button" onClick={togglePause} className="btn-arcade press-go w-full rounded-xl bg-go py-3 font-display text-go-ink">Reprendre</button>
              <button type="button" onClick={onRestart} className="btn-arcade press-gold w-full rounded-xl bg-gold py-3 font-display text-gold-ink">Recommencer</button>
              <button type="button" onClick={onExit} className="btn-arcade press-pit w-full rounded-xl bg-asphalt py-3 font-display text-ink">Changer les paris</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
