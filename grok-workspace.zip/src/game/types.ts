export type Pt = { x: number; y: number };

export type CarDef = {
  id: number;
  name: string;
  short: string;
  hex: string;
  dark: string;
  light: string;
  stripe: string;
};

export type SectionKind = "tunnel" | "bridge";

export type TrackSection = {
  from: number;
  to: number;
  kind: SectionKind;
};

export type DecorKind = "tree" | "cactus" | "lamp" | "rock" | "pine" | "building" | "stand";

export type TrackDef = {
  id: string;
  name: string;
  badge: string;
  grip: number;
  night: boolean;
  decor: DecorKind;
  grass: string;
  grassStripe: string;
  asphalt: string;
  asphaltInner: string;
  curbLight: string;
  curbDark: string;
  points: Pt[];
  sections: TrackSection[];
};

export type RaceMode = "gp" | "timetrial" | "elimination" | "teams";
export type WeatherSetting = "clear" | "rain" | "fog" | "wind" | "random";
export type LiveWeather = "clear" | "rain" | "fog" | "wind";
export type ZoneKind = "boost" | "gravel" | "oil" | "jump";

export type Zone = {
  id: string;
  at: number;
  length: number;
  kind: ZoneKind;
  lane: number;
  width: number;
};

export type Player = {
  id: number;
  name: string;
  carId: number;
  score: number;
  wins: number;
  podiums: number;
};

export type ChampStanding = {
  playerId: number;
  points: number;
  wins: number;
};

export type Championship = {
  id: string;
  rounds: number;
  round: number;
  trackIds: string[];
  mode: RaceMode;
  weather: WeatherSetting;
  carCount: number;
  lapCount: number;
  safetyCar: boolean;
  standings: ChampStanding[];
  completed: boolean;
  history: { round: number; trackId: string; winner: string }[];
};

export type Trophy = {
  id: string;
  title: string;
  playerName: string;
  detail: string;
  date: string;
};

export type TrackRecord = {
  ms: number;
  carName: string;
  holder: string;
  date: string;
};

export type SaveData = {
  version: 1;
  players: Player[];
  nextPlayerId: number;
  sound: boolean;
  mode: RaceMode;
  weather: WeatherSetting;
  trackId: string;
  carCount: number;
  lapCount: number;
  safetyCar: boolean;
  selectedCar: number;
  records: Record<string, TrackRecord>;
  championship: Championship | null;
  trophies: Trophy[];
};

export type RaceConfig = {
  trackId: string;
  mode: RaceMode;
  weather: WeatherSetting;
  carCount: number;
  lapCount: number;
  safetyCar: boolean;
  players: Player[];
};

export type ResultRow = {
  id: number;
  name: string;
  short: string;
  hex: string;
  light: string;
  team: 0 | 1;
  rank: number;
  eliminated: boolean;
  finishTime: number | null;
};

export type RaceResult = {
  mode: RaceMode;
  weather: LiveWeather;
  trackId: string;
  trackName: string;
  rows: ResultRow[];
  scCount: number;
  clock: number;
};

export type ScoredBet = {
  playerId: number;
  gained: number;
  badge: string;
  tone: "gold" | "silver" | "bronze" | "muted" | "team";
  carRank: number;
};
