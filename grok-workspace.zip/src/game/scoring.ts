import type { Player, RaceResult, ResultRow, ScoredBet } from "./types";

export function formatTime(sec: number) {
  const safe = Math.max(0, sec);
  const m = Math.floor(safe / 60);
  const s = safe - m * 60;
  const whole = Math.floor(s);
  const tenth = Math.floor((s - whole) * 10);
  return `${m}:${whole.toString().padStart(2, "0")}.${tenth}`;
}

function teamWinner(rows: ResultRow[]): 0 | 1 {
  const avg = (team: 0 | 1) => {
    const list = rows.filter((r) => r.team === team);
    if (list.length === 0) return 99;
    return list.reduce((sum, r) => sum + r.rank, 0) / list.length;
  };
  const best = (team: 0 | 1) => {
    const list = rows.filter((r) => r.team === team);
    if (list.length === 0) return 99;
    return Math.min(...list.map((r) => r.rank));
  };
  const a0 = avg(0);
  const a1 = avg(1);
  if (a1 < a0 - 0.001) return 1;
  if (Math.abs(a0 - a1) <= 0.001 && best(1) < best(0)) return 1;
  return 0;
}

export function scoreRace(result: RaceResult, players: Player[]): ScoredBet[] {
  const byId = new Map(result.rows.map((r) => [r.id, r]));
  if (result.mode === "teams") {
    const win = teamWinner(result.rows);
    const mates = result.rows.filter((r) => r.team === win);
    const bestRank = mates.length ? Math.min(...mates.map((r) => r.rank)) : 1;
    return players.map((p) => {
      const car = byId.get(p.carId);
      const carRank = car?.rank ?? 99;
      if (!car || car.team !== win) {
        return { playerId: p.id, gained: 0, badge: "Équipe battue", tone: "muted", carRank };
      }
      if (car.rank === bestRank) {
        return { playerId: p.id, gained: 3, badge: "Meilleur de l'équipe gagnante (+3)", tone: "gold", carRank };
      }
      return { playerId: p.id, gained: 1, badge: "Équipe gagnante (+1)", tone: "team", carRank };
    });
  }

  return players.map((p) => {
    const car = byId.get(p.carId);
    const carRank = car?.rank ?? 99;
    if (carRank === 1) {
      const badge =
        result.mode === "timetrial"
          ? "Meilleur temps (+3)"
          : result.mode === "elimination"
            ? "Survivant (+3)"
            : "Gagnant (+3)";
      return { playerId: p.id, gained: 3, badge, tone: "gold", carRank };
    }
    if (carRank === 2) return { playerId: p.id, gained: 1, badge: "2e place (+1)", tone: "silver", carRank };
    if (carRank === 3) return { playerId: p.id, gained: 0, badge: "3e sur le podium", tone: "bronze", carRank };
    return {
      playerId: p.id,
      gained: 0,
      badge: result.mode === "elimination" && car?.eliminated ? "Éliminé" : "Hors points",
      tone: "muted",
      carRank,
    };
  });
}

export function teamWinnerOf(result: RaceResult): 0 | 1 {
  return teamWinner(result.rows);
}
