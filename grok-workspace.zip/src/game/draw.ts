import type { RaceSim } from "./sim";
import { buildSpline, poseAt, type Spline } from "./spline";
import type { TrackDef } from "./types";

function trace(ctx: CanvasRenderingContext2D, spline: Spline) {
  const pts = spline.points;
  ctx.beginPath();
  for (let i = 0; i < pts.length; i++) {
    if (i === 0) ctx.moveTo(pts[i].x, pts[i].y);
    else ctx.lineTo(pts[i].x, pts[i].y);
  }
  ctx.closePath();
}

function strokeRange(ctx: CanvasRenderingContext2D, spline: Spline, from: number, to: number, color: string, width: number) {
  const pts = spline.points;
  const n = pts.length;
  const i0 = Math.floor(from * n);
  const i1 = Math.min(n - 1, Math.floor(to * n));
  if (i1 <= i0) return;
  ctx.beginPath();
  for (let i = i0; i <= i1; i++) {
    const p = pts[i];
    if (i === i0) ctx.moveTo(p.x, p.y);
    else ctx.lineTo(p.x, p.y);
  }
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.stroke();
}

function drawDecor(ctx: CanvasRenderingContext2D, spline: Spline, night: boolean) {
  for (const d of spline.decorations) {
    ctx.save();
    ctx.translate(d.x, d.y);
    ctx.scale(d.scale, d.scale);
    if (d.kind === "tree") {
      ctx.fillStyle = "rgba(0,0,0,0.28)";
      ctx.beginPath();
      ctx.arc(3, 5, 11, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = d.shade > 0.5 ? "#15803d" : "#166534";
      ctx.beginPath();
      ctx.arc(0, 0, 11, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#22c55e";
      ctx.beginPath();
      ctx.arc(-3, -3, 5.5, 0, Math.PI * 2);
      ctx.fill();
    } else if (d.kind === "cactus") {
      ctx.fillStyle = "#3f6212";
      ctx.fillRect(-3, -14, 6, 26);
      ctx.fillRect(-10, -4, 8, 4);
      ctx.fillRect(3, -8, 8, 4);
    } else if (d.kind === "pine") {
      ctx.fillStyle = "#0f172a";
      ctx.fillRect(-1.5, 6, 3, 8);
      ctx.fillStyle = d.shade > 0.5 ? "#334155" : "#1e3a5f";
      ctx.beginPath();
      ctx.moveTo(0, -16);
      ctx.lineTo(10, 8);
      ctx.lineTo(-10, 8);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.85)";
      ctx.beginPath();
      ctx.moveTo(0, -16);
      ctx.lineTo(4, -6);
      ctx.lineTo(-2, -8);
      ctx.closePath();
      ctx.fill();
    } else if (d.kind === "rock") {
      ctx.fillStyle = d.shade > 0.5 ? "#78716c" : "#a8a29e";
      ctx.beginPath();
      ctx.moveTo(-10, 6);
      ctx.lineTo(-6, -8);
      ctx.lineTo(4, -10);
      ctx.lineTo(12, 2);
      ctx.lineTo(2, 8);
      ctx.closePath();
      ctx.fill();
    } else if (d.kind === "building") {
      const h = 18 + d.shade * 16;
      ctx.fillStyle = "#0c0a09";
      ctx.fillRect(-9, -h, 18, h + 6);
      ctx.fillStyle = d.shade > 0.45 ? "#fbbf24" : "#67e8f9";
      for (let y = -h + 4; y < 2; y += 7) {
        ctx.fillRect(-6, y, 3, 3);
        ctx.fillRect(2, y, 3, 3);
      }
    } else if (d.kind === "lamp") {
      ctx.strokeStyle = "#334155";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, 8);
      ctx.lineTo(0, -12);
      ctx.stroke();
      const glow = ctx.createRadialGradient(0, -14, 1, 0, -14, night ? 22 : 12);
      glow.addColorStop(0, "rgba(253,224,71,0.9)");
      glow.addColorStop(1, "rgba(253,224,71,0)");
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(0, -14, night ? 22 : 12, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = "#1e293b";
      ctx.fillRect(-16, -8, 32, 14);
      ctx.fillStyle = "#f8fafc";
      ctx.fillRect(-16, -10, 32, 3);
      ctx.fillStyle = "#ef4444";
      for (let x = -14; x < 14; x += 6) ctx.fillRect(x, -10, 3, 3);
    }
    ctx.restore();
  }
}

function drawZones(ctx: CanvasRenderingContext2D, spline: Spline) {
  for (const zone of spline.zones) {
    const steps = 5;
    for (let s = 0; s < steps; s++) {
      const frac = zone.at + (zone.length * s) / steps;
      const pose = poseAt(spline, frac * spline.totalLength, zone.lane);
      ctx.save();
      ctx.translate(pose.x, pose.y);
      ctx.rotate(pose.angle);
      if (zone.kind === "boost") {
        ctx.strokeStyle = "#fbbf24";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(-6, -6);
        ctx.lineTo(2, 0);
        ctx.lineTo(-6, 6);
        ctx.stroke();
      } else if (zone.kind === "jump") {
        ctx.fillStyle = "#e2e8f0";
        ctx.beginPath();
        ctx.moveTo(-8, 7);
        ctx.lineTo(6, 0);
        ctx.lineTo(-8, -7);
        ctx.closePath();
        ctx.globalAlpha = 0.85;
        ctx.fill();
      } else if (zone.kind === "gravel") {
        ctx.fillStyle = "#d6d3d1";
        for (let k = 0; k < 4; k++) {
          ctx.beginPath();
          ctx.arc(-4 + k * 3, (k % 2) * 4 - 2, 1.6, 0, Math.PI * 2);
          ctx.fill();
        }
      } else {
        ctx.fillStyle = "rgba(15,23,42,0.82)";
        ctx.beginPath();
        ctx.ellipse(0, 0, 12, 6, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "rgba(56,189,248,0.8)";
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
      ctx.restore();
    }
  }
}

function drawStart(ctx: CanvasRenderingContext2D, spline: Spline) {
  const p = spline.points[0];
  const road = spline.roadWidth;
  ctx.save();
  ctx.translate(p.x, p.y);
  ctx.rotate(p.angle);
  const squares = 8;
  const size = road / squares;
  for (let r = 0; r < squares; r++) {
    for (let c = 0; c < 2; c++) {
      ctx.fillStyle = (r + c) % 2 === 0 ? "#ffffff" : "#0f172a";
      ctx.fillRect(-size + c * size, -road / 2 + r * size, size, size);
    }
  }
  ctx.restore();
}

function drawPortal(ctx: CanvasRenderingContext2D, spline: Spline, frac: number) {
  const pose = poseAt(spline, frac * spline.totalLength, 0);
  const road = spline.roadWidth;
  ctx.save();
  ctx.translate(pose.x, pose.y);
  ctx.rotate(pose.angle);
  ctx.fillStyle = "#020617";
  ctx.fillRect(-5, -road * 0.62, 10, road * 0.16);
  ctx.strokeStyle = "#334155";
  ctx.lineWidth = 3;
  ctx.strokeRect(-7, -road * 0.62, 14, road * 1.24);
  ctx.restore();
}

function drawRails(ctx: CanvasRenderingContext2D, spline: Spline, from: number, to: number) {
  const pts = spline.points;
  const n = pts.length;
  const i0 = Math.floor(from * n);
  const i1 = Math.min(n - 1, Math.floor(to * n));
  const road = spline.roadWidth;
  for (const side of [-1, 1]) {
    ctx.beginPath();
    for (let i = i0; i <= i1; i++) {
      const p = pts[i];
      const x = p.x + p.nx * side * (road * 0.58);
      const y = p.y + p.ny * side * (road * 0.58);
      if (i === i0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = "#e7e5e4";
    ctx.lineWidth = 3;
    ctx.stroke();
  }
}

function drawCar(
  ctx: CanvasRenderingContext2D,
  car: RaceSim["cars"][number],
  racing: boolean,
  label: string,
) {
  ctx.save();
  ctx.translate(car.x, car.y - car.airHeight * 16);
  ctx.rotate(car.angle + car.spin * 0.35);
  if (car.inTunnel) ctx.globalAlpha = 0.78;
  if (car.eliminated) ctx.globalAlpha = 0.4;
  const len = 24;
  const wid = 13;
  if (car.airHeight > 0.05) {
    ctx.save();
    ctx.translate(0, car.airHeight * 16);
    ctx.fillStyle = "rgba(0,0,0,0.25)";
    ctx.beginPath();
    ctx.ellipse(0, 0, 12, 6, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  if (racing && car.status === "boost" && !car.eliminated) {
    const flame = 8 + Math.random() * 6;
    ctx.fillStyle = "#f97316";
    ctx.beginPath();
    ctx.moveTo(-len * 0.5, -3);
    ctx.lineTo(-len * 0.5 - flame, 0);
    ctx.lineTo(-len * 0.5, 3);
    ctx.closePath();
    ctx.fill();
  }
  if (car.inTunnel || racing) {
    ctx.fillStyle = car.inTunnel ? "rgba(253,224,71,0.55)" : "rgba(253,224,71,0.0)";
    if (car.inTunnel) {
      ctx.beginPath();
      ctx.moveTo(len * 0.45, -3);
      ctx.lineTo(len * 0.45 + 18, -9);
      ctx.lineTo(len * 0.45 + 18, 9);
      ctx.lineTo(len * 0.45, 3);
      ctx.fill();
    }
  }
  ctx.fillStyle = "rgba(0,0,0,0.4)";
  ctx.beginPath();
  ctx.roundRect(-len * 0.5 + 2, -wid * 0.5 + 3, len, wid, 4);
  ctx.fill();
  ctx.fillStyle = "#090d16";
  const ww = 5.5;
  const wh = 3.2;
  ctx.fillRect(len * 0.22 - ww / 2, -wid * 0.5 - 1.6, ww, wh);
  ctx.fillRect(len * 0.22 - ww / 2, wid * 0.5 - 1.6, ww, wh);
  ctx.fillRect(-len * 0.26 - ww / 2, -wid * 0.5 - 1.6, ww, wh);
  ctx.fillRect(-len * 0.26 - ww / 2, wid * 0.5 - 1.6, ww, wh);
  ctx.fillStyle = car.hex;
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.roundRect(-len * 0.5, -wid * 0.5, len, wid, 4.5);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = car.stripe;
  ctx.fillRect(-len * 0.42, -1.5, len * 0.84, 3);
  ctx.fillStyle = "#0f172a";
  ctx.beginPath();
  ctx.roundRect(-3.5, -wid * 0.34, 8.5, wid * 0.68, 2);
  ctx.fill();
  ctx.fillStyle = "rgba(186,230,253,0.45)";
  ctx.beginPath();
  ctx.roundRect(-1.5, -wid * 0.28, 3.5, wid * 0.56, 1);
  ctx.fill();
  ctx.fillStyle = car.dark;
  ctx.fillRect(-len * 0.5 - 1, -wid * 0.46, 3.2, wid * 0.92);
  if (car.braking && racing && !car.eliminated) {
    ctx.fillStyle = "#ff2a2a";
    ctx.fillRect(-len * 0.5 - 1, -wid * 0.38, 1.8, 2.5);
    ctx.fillRect(-len * 0.5 - 1, wid * 0.38 - 2.5, 1.8, 2.5);
  }
  ctx.restore();

  ctx.save();
  ctx.font = "700 10px Outfit, sans-serif";
  ctx.textAlign = "center";
  const text = car.eliminated ? `${car.rank} OUT` : label;
  const tw = ctx.measureText(text).width + 8;
  const by = car.y - 18 - car.airHeight * 16;
  ctx.fillStyle = "rgba(15,23,42,0.88)";
  ctx.beginPath();
  ctx.roundRect(car.x - tw / 2, by - 9, tw, 13, 4);
  ctx.fill();
  ctx.strokeStyle = car.hex;
  ctx.lineWidth = 1.2;
  ctx.stroke();
  ctx.fillStyle = "#ffffff";
  ctx.fillText(text, car.x, by);
  ctx.restore();
}

function drawSafety(ctx: CanvasRenderingContext2D, sim: RaceSim) {
  if (!sim.sc.active) return;
  const blink = Math.floor(sim.sc.blink * 8) % 2 === 0;
  ctx.save();
  ctx.translate(sim.sc.x, sim.sc.y);
  ctx.rotate(sim.sc.angle);
  ctx.fillStyle = "#f8fafc";
  ctx.strokeStyle = "#0f172a";
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.roundRect(-16, -8, 32, 16, 4);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#f97316";
  ctx.fillRect(-12, -2, 24, 4);
  ctx.fillStyle = blink ? "#facc15" : "#ea580c";
  ctx.beginPath();
  ctx.arc(0, -8, 3.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  ctx.save();
  ctx.font = "700 10px Fredoka, sans-serif";
  ctx.textAlign = "center";
  ctx.fillStyle = "#0f172a";
  ctx.fillRect(sim.sc.x - 14, sim.sc.y - 28, 28, 12);
  ctx.fillStyle = "#fbbf24";
  ctx.fillText("SC", sim.sc.x, sim.sc.y - 18);
  ctx.restore();
}

function paintTrack(ctx: CanvasRenderingContext2D, track: TrackDef, spline: Spline, w: number, h: number) {
  ctx.fillStyle = track.grass;
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = track.grassStripe;
  for (let y = 0; y < h; y += 56) ctx.fillRect(0, y, w, 28);
  drawDecor(ctx, spline, track.night);
  const road = spline.roadWidth;
  for (const section of track.sections) {
    if (section.kind !== "bridge") continue;
    strokeRange(ctx, spline, section.from, section.to, "rgba(14,165,233,0.35)", road + 36);
  }
  trace(ctx, spline);
  ctx.strokeStyle = "rgba(0,0,0,0.35)";
  ctx.lineWidth = road + 16;
  ctx.lineJoin = "round";
  ctx.stroke();
  trace(ctx, spline);
  ctx.strokeStyle = track.curbLight;
  ctx.lineWidth = road + 8;
  ctx.stroke();
  const step = 8;
  for (let i = 0; i < spline.points.length; i += step * 2) {
    ctx.beginPath();
    for (let j = 0; j <= step; j++) {
      const p = spline.points[(i + j) % spline.points.length];
      if (j === 0) ctx.moveTo(p.x, p.y);
      else ctx.lineTo(p.x, p.y);
    }
    ctx.strokeStyle = track.curbDark;
    ctx.lineWidth = road + 8;
    ctx.lineCap = "butt";
    ctx.stroke();
  }
  trace(ctx, spline);
  ctx.strokeStyle = track.asphalt;
  ctx.lineWidth = road;
  ctx.lineJoin = "round";
  ctx.stroke();
  trace(ctx, spline);
  ctx.strokeStyle = track.asphaltInner;
  ctx.lineWidth = road * 0.72;
  ctx.stroke();
  ctx.save();
  trace(ctx, spline);
  ctx.strokeStyle = "rgba(255,255,255,0.16)";
  ctx.lineWidth = 2;
  ctx.setLineDash([12, 14]);
  ctx.stroke();
  ctx.restore();
  for (const section of track.sections) {
    if (section.kind === "tunnel") {
      strokeRange(ctx, spline, section.from, section.to, "rgba(2,6,23,0.55)", road * 0.92);
      drawPortal(ctx, spline, section.from);
      drawPortal(ctx, spline, section.to);
    } else {
      drawRails(ctx, spline, section.from, section.to);
    }
  }
  drawZones(ctx, spline);
  drawStart(ctx, spline);
}

export function drawMini(canvas: HTMLCanvasElement, track: TrackDef) {
  const w = 160;
  const h = 200;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = w * dpr;
  canvas.height = h * dpr;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const spline = buildSpline(track, w, h, 280);
  paintTrack(ctx, track, spline, w, h);
  const start = spline.points[0];
  ctx.fillStyle = "#fbbf24";
  ctx.beginPath();
  ctx.arc(start.x, start.y, 4, 0, Math.PI * 2);
  ctx.fill();
}

export function drawWorld(ctx: CanvasRenderingContext2D, sim: RaceSim, w: number, h: number) {
  ctx.clearRect(0, 0, w, h);
  ctx.save();
  if (sim.shake > 0) {
    ctx.translate(Math.sin(sim.shake * 48) * 4, Math.cos(sim.shake * 36) * 2.5);
  }
  paintTrack(ctx, sim.track, sim.spline, w, h);
  for (const p of sim.particles) {
    ctx.save();
    ctx.globalAlpha = Math.max(0, p.life / p.max);
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  drawSafety(ctx, sim);
  const names = sim.hud().rows;
  const byId = new Map(names.map((r) => [r.rank, r.label]));
  const cars = [...sim.cars].sort((a, b) => a.totalDistance - b.totalDistance);
  for (const car of cars) {
    const place = car.rank === 1 ? "1er" : `${car.rank}e`;
    const label = `${place} ${byId.get(car.rank) ?? car.short}`.slice(0, 22);
    drawCar(ctx, car, sim.status === "racing", label);
  }
  if (sim.track.night) {
    const g = ctx.createRadialGradient(w / 2, h / 2, w * 0.2, w / 2, h / 2, w * 0.72);
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(1, "rgba(0,0,0,0.45)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }
  if (sim.weather === "fog") {
    const g = ctx.createRadialGradient(w / 2, h / 2, w * 0.08, w / 2, h / 2, w * 0.7);
    g.addColorStop(0, "rgba(226,232,240,0.05)");
    g.addColorStop(1, "rgba(203,213,225,0.72)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }
  if (sim.weather === "rain") {
    ctx.strokeStyle = "rgba(226,232,240,0.45)";
    ctx.lineWidth = 1.4;
    for (const drop of sim.rain) {
      ctx.beginPath();
      ctx.moveTo(drop.x, drop.y);
      ctx.lineTo(drop.x + 3, drop.y + drop.len);
      ctx.stroke();
    }
  }
  if (sim.weather === "wind") {
    ctx.strokeStyle = "rgba(248,250,252,0.25)";
    ctx.lineWidth = 2;
    const shift = (sim.clock * 80) % (w + 40);
    for (let i = 0; i < 5; i++) {
      const y = 40 + i * (h / 6);
      ctx.beginPath();
      ctx.moveTo(-40 + shift * 0.3 + i * 20, y);
      ctx.bezierCurveTo(40 + i * 30, y - 8, 90 + i * 20, y + 10, 160 + i * 24, y);
      ctx.stroke();
    }
  }
  ctx.restore();
}
