import { CARS } from "./data";
import { buildSpline, clamp, fractionOf, poseAt, type Spline } from "./spline";
import type { LiveWeather, Player, RaceMode, RaceResult, TrackDef, WeatherSetting } from "./types";

export type SimStatus = "countdown" | "racing" | "paused" | "finished";

type SimCar = {
  id: number;
  name: string;
  short: string;
  hex: string;
  dark: string;
  light: string;
  stripe: string;
  team: 0 | 1;
  homeLane: number;
  lane: number;
  targetLane: number;
  laneCd: number;
  totalDistance: number;
  speed: number;
  baseSpeed: number;
  lap: number;
  finished: boolean;
  finishTime: number | null;
  eliminated: boolean;
  elimSeq: number;
  rank: number;
  status: "normal" | "boost" | "tire" | "oil" | "air";
  statusTimer: number;
  boostFactor: number;
  braking: boolean;
  airborne: number;
  airHeight: number;
  spin: number;
  gripPenalty: number;
  zoneSet: Set<string>;
  onGravel: boolean;
  inTunnel: boolean;
  onBridge: boolean;
  x: number;
  y: number;
  angle: number;
  curvature: number;
};

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  r: number;
  color: string;
};

type RainDrop = { x: number; y: number; v: number; len: number };

export type HudRow = {
  rank: number;
  hex: string;
  label: string;
  flag: string;
  team: 0 | 1;
};

export type HudSnap = {
  lap: string;
  clock: number;
  weather: LiveWeather;
  mode: RaceMode;
  ticker: { text: string; kind: string } | null;
  scReason: string | null;
  scPhase: string | null;
  alive: number;
  rows: HudRow[];
  teamBest: [number, number] | null;
};

export class RaceSim {
  status: SimStatus = "countdown";
  cars: SimCar[] = [];
  particles: Particle[] = [];
  rain: RainDrop[] = [];
  spline: Spline;
  clock = 0;
  speedMult = 1;
  shake = 0;
  weather: LiveWeather;
  weatherLeft: number;
  sc = {
    active: false,
    phase: "deploy" as "deploy" | "hold" | "withdraw",
    distance: 0,
    timer: 0,
    blink: 0,
    reason: "",
    x: 0,
    y: 0,
    angle: 0,
  };
  scCooldown = 6;
  scCount = 0;
  events: string[] = [];
  ticker = { text: "", kind: "", until: -1 };
  elimMarker = 0;
  elimCount = 0;
  w: number;
  h: number;
  readonly track: TrackDef;
  private readonly mode: RaceMode;
  private readonly carCount: number;
  private readonly lapCount: number;
  private readonly players: Player[];
  private over = false;
  private celebrated = false;
  private built: RaceResult | null = null;
  private safetyEnabled: boolean;
  private readonly weatherSetting: WeatherSetting;

  constructor(
    track: TrackDef,
    mode: RaceMode,
    weather: WeatherSetting,
    carCount: number,
    lapCount: number,
    safetyCar: boolean,
    players: Player[],
    width: number,
    height: number,
  ) {
    this.track = track;
    this.mode = mode;
    this.carCount = carCount;
    this.lapCount = lapCount;
    this.players = players;
    this.w = Math.max(40, width);
    this.h = Math.max(40, height);
    this.spline = buildSpline(track, this.w, this.h);
    this.weatherSetting = weather;
    this.weather = weather === "random" ? "clear" : weather;
    this.weatherLeft = 16;
    this.safetyEnabled = mode === "timetrial" ? false : safetyCar;
    this.initCars();
    this.syncAll();
  }

  resize(w: number, h: number) {
    if (w < 20 || h < 20) return;
    if (Math.abs(w - this.w) < 1 && Math.abs(h - this.h) < 1) return;
    const old = this.spline.totalLength || 1;
    this.w = w;
    this.h = h;
    this.spline = buildSpline(this.track, w, h);
    const ratio = this.spline.totalLength / old;
    if (Math.abs(ratio - 1) > 0.002) {
      for (const car of this.cars) car.totalDistance *= ratio;
      this.sc.distance *= ratio;
    }
    this.syncAll();
  }

  greenFlag() {
    if (this.status === "finished") return;
    this.status = "racing";
    this.pushTicker("Zones : boost, gravier, huile, sauts", "info", true);
  }

  consumeEvents() {
    const copy = this.events;
    this.events = [];
    return copy;
  }

  update(dt: number) {
    if (this.status !== "racing") return;
    const step = Math.min(0.05, dt) * this.speedMult;
    this.clock += step;
    this.shake = Math.max(0, this.shake - step);
    this.updateWeather(step);
    this.updateRain(step);
    const scale = this.spline.totalLength / 950;
    const sc = this.updateSafety(step, scale);
    const active = this.cars.filter((c) => !c.eliminated && !c.finished);
    const maxD = active.reduce((m, c) => Math.max(m, c.totalDistance), -Infinity);

    for (const car of this.cars) this.syncOne(car);
    for (const car of this.cars) this.stepCar(car, step, scale, maxD, sc);
    this.syncAll();
    if (this.sc.active) {
      const pose = poseAt(this.spline, this.sc.distance, 0);
      this.sc.x = pose.x;
      this.sc.y = pose.y;
      this.sc.angle = pose.angle;
    }
    this.ageParticles(step);
    if (this.mode === "elimination") this.eliminateIfNeeded();
    this.rankCars();
    this.detectIncidents(step, scale);
    this.maybeFinish();
  }

  hud(): HudSnap {
    const leader = [...this.cars].sort((a, b) => a.rank - b.rank)[0];
    const alive = this.cars.filter((c) => !c.eliminated && !c.finished).length;
    const rows: HudRow[] = [...this.cars]
      .sort((a, b) => a.rank - b.rank)
      .map((car) => {
        const names = this.players.filter((p) => p.carId === car.id).map((p) => p.name);
        const flag = car.eliminated ? "out" : car.finished ? "finish" : car.status === "boost" ? "boost" : car.status === "oil" ? "oil" : "";
        return {
          rank: car.rank,
          hex: car.hex,
          label: names.length ? names.join(", ") : car.short,
          flag,
          team: car.team,
        };
      });
    let teamBest: [number, number] | null = null;
    if (this.mode === "teams") {
      const best = (team: 0 | 1) => {
        const list = this.cars.filter((c) => c.team === team);
        return list.reduce((m, c) => Math.min(m, c.rank), 99);
      };
      teamBest = [best(0), best(1)];
    }
    return {
      lap: leader ? `${leader.eliminated ? "OUT" : `TOUR ${leader.lap} / ${this.lapCount}`}` : "",
      clock: this.clock,
      weather: this.weather,
      mode: this.mode,
      ticker: this.clock < this.ticker.until && this.ticker.text ? { text: this.ticker.text, kind: this.ticker.kind } : null,
      scReason: this.sc.active ? this.sc.reason : null,
      scPhase: this.sc.active ? this.sc.phase : null,
      alive,
      rows,
      teamBest,
    };
  }

  result(): RaceResult {
    if (this.built) return this.built;
    this.rankCars();
    const rows = [...this.cars]
      .sort((a, b) => a.rank - b.rank)
      .map((c) => ({
        id: c.id,
        name: c.name,
        short: c.short,
        hex: c.hex,
        light: c.light,
        team: c.team,
        rank: c.rank,
        eliminated: c.eliminated,
        finishTime: c.finishTime,
      }));
    this.built = {
      mode: this.mode,
      weather: this.weather,
      trackId: this.track.id,
      trackName: this.track.name,
      rows,
      scCount: this.scCount,
      clock: this.clock,
    };
    return this.built;
  }

  private initCars() {
    const n = Math.max(3, Math.min(6, this.carCount));
    this.cars = [];
    for (let i = 0; i < n; i++) {
      const catalog = CARS[i];
      const home = i % 2 === 0 ? -0.42 : 0.42;
      this.cars.push({
        id: catalog.id,
        name: catalog.name,
        short: catalog.short,
        hex: catalog.hex,
        dark: catalog.dark,
        light: catalog.light,
        stripe: catalog.stripe,
        team: (i % 2) as 0 | 1,
        homeLane: home,
        lane: home,
        targetLane: home,
        laneCd: 0.4 + Math.random() * 0.6,
        totalDistance: -20 - i * 18,
        speed: 0,
        baseSpeed: 156 + ((i * 13) % 11) - 4,
        lap: 1,
        finished: false,
        finishTime: null,
        eliminated: false,
        elimSeq: 0,
        rank: i + 1,
        status: "normal",
        statusTimer: 1.2 + Math.random() * 1.8,
        boostFactor: 1,
        braking: false,
        airborne: 0,
        airHeight: 0,
        spin: 0,
        gripPenalty: 0,
        zoneSet: new Set(),
        onGravel: false,
        inTunnel: false,
        onBridge: false,
        x: 0,
        y: 0,
        angle: 0,
        curvature: 0,
      });
    }
  }

  private updateWeather(dt: number) {
    if (this.weatherSetting !== "random") return;
    this.weatherLeft -= dt;
    if (this.weatherLeft > 0) return;
    const options: LiveWeather[] = ["clear", "rain", "fog", "wind"];
    const next = options[Math.floor(Math.random() * options.length)] ?? "clear";
    if (next !== this.weather) {
      this.weather = next;
      const label = next === "rain" ? "La pluie arrive" : next === "fog" ? "Le brouillard tombe" : next === "wind" ? "Rafales de vent" : "Le ciel se dégage";
      this.pushTicker(label, "weather", true);
    }
    this.weatherLeft = 16 + Math.random() * 8;
  }

  private updateRain(dt: number) {
    if (this.weather !== "rain") {
      this.rain = [];
      return;
    }
    while (this.rain.length < 70) {
      this.rain.push({
        x: Math.random() * this.w,
        y: Math.random() * this.h,
        v: 420 + Math.random() * 280,
        len: 10 + Math.random() * 12,
      });
    }
    for (const drop of this.rain) {
      drop.y += drop.v * dt;
      drop.x += 40 * dt;
      if (drop.y > this.h + 8) {
        drop.y = -12;
        drop.x = Math.random() * this.w;
      }
    }
  }

  private updateSafety(dt: number, scale: number) {
    if (!this.sc.active) {
      this.scCooldown -= dt;
      return { active: false, pace: Infinity, release: 1 };
    }
    this.sc.timer += dt;
    this.sc.blink += dt;
    const active = this.cars.filter((c) => !c.finished && !c.eliminated);
    if (active.length === 0) {
      this.sc.active = false;
      return { active: false, pace: Infinity, release: 1 };
    }
    const maxD = Math.max(...active.map((c) => c.totalDistance));
    const minD = Math.min(...active.map((c) => c.totalDistance));
    const len = this.spline.totalLength;
    const pace = 148 * scale * 0.56;
    if (this.sc.phase !== "withdraw") {
      const desired = maxD + 52 * scale;
      if (this.sc.distance < desired) this.sc.distance = desired;
    } else {
      this.sc.distance += pace * 2.6 * dt;
    }
    const gap = maxD - minD;
    if (this.sc.phase === "deploy" && (gap < len * 0.075 || this.sc.timer > 9)) {
      this.sc.phase = "hold";
      this.sc.timer = 0;
      this.pushTicker("Peloton derrière la Safety Car", "sc", true);
    } else if (this.sc.phase === "hold" && this.sc.timer > 3.4) {
      this.sc.phase = "withdraw";
      this.sc.timer = 0;
      this.pushTicker("La Safety Car rentre aux stands", "sc", true);
      this.events.push("restart");
    } else if (this.sc.phase === "withdraw" && this.sc.timer > 1.7) {
      this.sc.active = false;
      this.scCooldown = 18;
    }
    const release = this.sc.phase === "withdraw" ? clamp(this.sc.timer / 1.7, 0, 1) : 0;
    return { active: this.sc.active, pace, release };
  }

  private stepCar(
    car: SimCar,
    dt: number,
    scale: number,
    maxD: number,
    sc: { active: boolean; pace: number; release: number },
  ) {
    const len = this.spline.totalLength;
    if (car.finished || car.eliminated) {
      car.speed *= Math.pow(0.42, dt);
      if (car.eliminated) car.targetLane = 0.92;
      car.lane += (car.targetLane - car.lane) * Math.min(1, dt * 2.4);
      car.totalDistance += car.speed * dt;
      car.airHeight = 0;
      return;
    }

    car.laneCd -= dt;
    car.gripPenalty = Math.max(0, car.gripPenalty - dt);
    if (car.airborne > 0) {
      car.airborne -= dt;
      const t = 1 - car.airborne / 0.62;
      car.airHeight = Math.sin(clamp(t, 0, 1) * Math.PI);
      if (car.airborne <= 0) {
        car.airHeight = 0;
        car.airborne = 0;
        this.events.push("land");
        this.shake = Math.max(this.shake, 0.22);
        this.spawn(car, "smoke");
      }
    } else {
      car.airHeight = 0;
    }
    car.spin *= Math.max(0, 1 - dt * 2.4);

    if (this.mode !== "timetrial" && !sc.active && car.airborne <= 0) {
      car.statusTimer -= dt;
      if (car.statusTimer <= 0) {
        const gap = Math.max(0, maxD - car.totalDistance);
        const catchup = Math.min(0.28, gap / (len * 0.9));
        const roll = Math.random();
        if (roll < 0.2 + catchup) {
          car.status = "boost";
          car.boostFactor = 1.18 + Math.random() * 0.08;
          car.statusTimer = 1.2 + Math.random();
          if (Math.random() < 0.45) {
            this.events.push("boost");
            this.pushTicker(`${car.name} enclenche le nitro`, "boost");
          }
        } else if (roll < 0.34) {
          car.status = "tire";
          car.boostFactor = 0.88;
          car.statusTimer = 1 + Math.random() * 0.7;
        } else {
          car.status = "normal";
          car.boostFactor = 0.98 + Math.random() * 0.06;
          car.statusTimer = 1.3 + Math.random() * 1.4;
        }
      }
    } else if (car.status === "tire" || (this.mode === "timetrial" && car.status === "boost" && car.boostFactor < 1.3)) {
      car.boostFactor += (1 - car.boostFactor) * Math.min(1, dt * 2);
    }

    let slip = 1;
    if (this.mode !== "timetrial" && !sc.active && car.airborne <= 0) {
      let blocked = false;
      for (const other of this.cars) {
        if (other.id === car.id || other.eliminated) continue;
        const ahead = other.totalDistance - car.totalDistance;
        if (ahead > 0 && ahead < 54 * scale && Math.abs(other.lane - car.lane) < 0.4) {
          blocked = true;
          slip = 1.1;
          if (car.laneCd <= 0) {
            const lanes = [-0.62, 0, 0.62].sort((a, b) => Math.abs(b - other.lane) - Math.abs(a - other.lane));
            car.targetLane = lanes[0] ?? 0;
            car.laneCd = 0.7 + Math.random() * 0.45;
          }
        }
      }
      if (!blocked && car.laneCd <= 0 && Math.random() < 0.03) {
        const lanes = [-0.45, 0, 0.45];
        car.targetLane = lanes[Math.floor(Math.random() * lanes.length)] ?? 0;
        car.laneCd = 1.2;
      }
    } else if (this.mode === "timetrial" && car.laneCd <= 0 && car.airborne <= 0) {
      car.targetLane = clamp(car.homeLane + (Math.random() - 0.5) * 0.12, -0.7, 0.7);
      car.laneCd = 1.6;
    }

    if (sc.active && sc.release < 1 && car.airborne <= 0) {
      car.targetLane = car.id % 2 === 0 ? -0.16 : 0.16;
    }
    if (car.airborne <= 0) car.lane += (car.targetLane - car.lane) * Math.min(1, dt * 4.2);

    const gravel = this.clock > 0.45 ? this.applyZones(car) : 1;
    const weatherGrip = this.weather === "rain" ? 0.74 : this.weather === "fog" ? 0.93 : this.weather === "wind" ? 0.96 : 1;
    const gripHit = 1 - Math.min(0.42, car.gripPenalty * 0.26);
    const grip = this.track.grip * weatherGrip * gripHit;
    const corner = Math.max(0.5, 1 - car.curvature * (0.7 + (1 - grip) * 0.85));
    car.braking = corner < 0.78 && car.airborne <= 0;
    const rubber = this.mode === "timetrial" ? 1 : 1 + (Math.max(0, maxD - car.totalDistance) / len) * 0.11;
    let target = car.baseSpeed * scale * car.boostFactor * corner * slip * rubber * grip * gravel;
    if (car.airborne > 0) target = car.baseSpeed * scale * 1.04;

    if (sc.active && sc.pace < Infinity) {
      const gapToLeader = Math.max(0, maxD - car.totalDistance);
      const catchup = Math.min(0.62, gapToLeader / (len * 0.12));
      let cap = sc.pace * (1.02 + catchup);
      cap = cap + target * sc.release;
      target = Math.min(target, cap);
    }

    if (this.weather === "wind" && car.airborne <= 0) {
      const gust = Math.sin(this.clock * 0.85) * 0.45 + Math.sin(this.clock * 1.7 + car.id) * 0.2;
      car.lane = clamp(car.lane + gust * dt * 0.62, -0.95, 0.95);
    }

    const rate = target > car.speed ? 3.5 : 5.2;
    car.speed += (target - car.speed) * Math.min(1, dt * rate);
    car.totalDistance += car.speed * dt;

    if (car.status === "boost" && Math.random() < 0.7) this.spawn(car, "flame");
    else if ((car.braking || car.onGravel) && Math.random() < 0.4) this.spawn(car, "smoke");
    else if (this.weather === "rain" && Math.random() < 0.5) this.spawn(car, "spray");

    const completed = Math.max(0, Math.floor(car.totalDistance / len));
    const nextLap = Math.min(this.lapCount, completed + 1);
    if (nextLap > car.lap && completed < this.lapCount) {
      car.lap = nextLap;
      if (car.rank === 1 && car.lap === this.lapCount) this.pushTicker("Dernier tour", "info", true);
    }
    if (completed >= this.lapCount && !car.finished) {
      car.finished = true;
      car.finishTime = this.clock;
      if (!this.celebrated && !this.cars.some((c) => c !== car && c.finished && !c.eliminated)) {
        this.celebrated = true;
        this.pushTicker(`Victoire de ${car.name}`, "win", true);
        this.events.push("win");
      }
    }

    const frac = fractionOf(car.totalDistance, len);
    car.inTunnel = this.track.sections.some((s) => s.kind === "tunnel" && frac >= s.from && frac <= s.to);
    car.onBridge = this.track.sections.some((s) => s.kind === "bridge" && frac >= s.from && frac <= s.to);
  }

  private applyZones(car: SimCar) {
    const len = this.spline.totalLength;
    const pos = fractionOf(car.totalDistance, len) * len;
    let gravel = 1;
    const inside = new Set<string>();
    car.onGravel = false;
    for (const zone of this.spline.zones) {
      const z0 = zone.at * len;
      const z1 = z0 + zone.length * len;
      if (pos < z0 || pos > z1) continue;
      if (Math.abs(car.lane - zone.lane) > zone.width) continue;
      inside.add(zone.id);
      const entered = !car.zoneSet.has(zone.id);
      if (zone.kind === "gravel") {
        gravel = 0.58;
        car.onGravel = true;
      }
      if (!entered || car.airborne > 0) continue;
      if (zone.kind === "boost") {
        car.boostFactor = Math.max(car.boostFactor, 1.38);
        car.status = "boost";
        car.statusTimer = Math.max(car.statusTimer, 0.9);
        this.events.push("boost");
        this.pushTicker(`${car.short} sur le boost`, "boost");
      } else if (zone.kind === "oil") {
        car.gripPenalty = 1.3;
        car.spin = (Math.random() > 0.5 ? 1 : -1) * 1.15;
        car.targetLane = clamp(car.lane + (car.spin > 0 ? 0.55 : -0.55), -0.9, 0.9);
        car.status = "oil";
        car.statusTimer = 1.15;
        this.pushTicker(`${car.short} sur l'huile`, "oil");
        this.spawn(car, "smoke");
        if (this.weather === "rain" && this.readyForIncident() && Math.random() < 0.55) {
          this.deploySafety(`${car.name} part en tête-à-queue`, car);
        }
      } else if (zone.kind === "jump") {
        car.airborne = 0.62;
        car.status = "air";
        this.events.push("jump");
        this.pushTicker(`${car.short} prend le saut`, "jump");
      }
    }
    car.zoneSet = inside;
    return gravel;
  }

  private eliminateIfNeeded() {
    if (this.sc.active) return;
    const alive = this.cars.filter((c) => !c.eliminated && !c.finished);
    if (alive.length < 2) return;
    const leader = alive.reduce((a, b) => (a.totalDistance > b.totalDistance ? a : b));
    const laps = Math.floor(Math.max(0, leader.totalDistance) / this.spline.totalLength);
    if (laps <= this.elimMarker) return;
    this.elimMarker = laps;
    const last = alive.reduce((a, b) => (a.totalDistance < b.totalDistance ? a : b));
    if (last.id === leader.id) return;
    last.eliminated = true;
    last.elimSeq = ++this.elimCount;
    last.speed *= 0.35;
    this.pushTicker(`${last.name} est éliminé`, "elim", true);
    this.events.push("elim");
    this.shake = Math.max(this.shake, 0.18);
  }

  private readyForIncident() {
    return this.safetyEnabled && !this.sc.active && this.scCooldown <= 0 && this.clock > 8 && this.scCount < 2;
  }

  private detectIncidents(dt: number, scale: number) {
    if (!this.readyForIncident()) return;
    const active = this.cars.filter((c) => !c.finished && !c.eliminated && c.airborne <= 0);
    for (let i = 0; i < active.length; i++) {
      for (let j = i + 1; j < active.length; j++) {
        const a = active[i];
        const b = active[j];
        if (Math.abs(a.totalDistance - b.totalDistance) < 22 * scale && Math.abs(a.lane - b.lane) < 0.28) {
          if (Math.random() < 0.2 * dt) {
            this.deploySafety(`Accrochage ${a.short} / ${b.short}`, a);
            return;
          }
        }
      }
    }
    for (const car of active) {
      if (car.onGravel && Math.abs(car.lane) > 0.72 && Math.random() < 0.1 * dt) {
        this.deploySafety(`${car.name} sort de piste`, car);
        return;
      }
    }
    const leader = active.reduce((a, b) => (a.totalDistance > b.totalDistance ? a : b), active[0]);
    if (leader && this.scCount === 0 && leader.lap >= 2 && this.clock > 12 && Math.random() < 0.28 * dt) {
      this.deploySafety("Débris signalés par les commissaires", leader);
    }
  }

  private deploySafety(reason: string, involved: SimCar) {
    if (!this.readyForIncident()) return;
    this.sc.active = true;
    this.sc.phase = "deploy";
    this.sc.timer = 0;
    this.sc.reason = reason;
    this.sc.distance = involved.totalDistance + this.spline.totalLength * 0.03;
    this.scCount += 1;
    involved.speed *= 0.45;
    involved.gripPenalty = Math.max(involved.gripPenalty, 0.8);
    this.pushTicker(`Safety Car — ${reason}`, "sc", true);
    this.events.push("sc");
    this.shake = Math.max(this.shake, 0.45);
    this.spawn(involved, "debris");
    this.spawn(involved, "debris");
  }

  private maybeFinish() {
    if (this.over) return;
    const racing = this.cars.filter((c) => !c.eliminated);
    if (this.mode === "elimination") {
      const alive = this.cars.filter((c) => !c.eliminated && !c.finished);
      if (alive.length <= 1 && this.elimCount > 0) {
        const survivor = alive[0];
        if (survivor && !survivor.finished) {
          survivor.finished = true;
          survivor.finishTime = this.clock;
        }
        if (!this.celebrated) {
          this.celebrated = true;
          this.pushTicker(`Survivant : ${survivor?.name ?? ""}`, "win", true);
          this.events.push("win");
        }
        this.finish();
        return;
      }
    }
    const allDone = racing.every((c) => c.finished);
    const winner = this.cars.filter((c) => c.finished && !c.eliminated).sort((a, b) => (a.finishTime ?? 0) - (b.finishTime ?? 0))[0];
    const wait = this.mode === "timetrial" ? 6.5 : 3.2;
    const need = Math.min(3, racing.length);
    const finishedCount = racing.filter((c) => c.finished).length;
    const timeout = !!winner && winner.finishTime != null && this.clock - winner.finishTime > wait && finishedCount >= need;
    if (allDone || timeout) this.finish();
  }

  private finish() {
    if (this.over) return;
    this.over = true;
    this.status = "finished";
    this.rankCars();
    this.result();
  }

  private rankCars() {
    const racing = this.cars.filter((c) => !c.eliminated);
    const done = racing.filter((c) => c.finished).sort((a, b) => (a.finishTime ?? 0) - (b.finishTime ?? 0));
    const running = racing.filter((c) => !c.finished).sort((a, b) => b.totalDistance - a.totalDistance);
    const out = this.cars.filter((c) => c.eliminated).sort((a, b) => b.elimSeq - a.elimSeq);
    [...done, ...running, ...out].forEach((car, index) => {
      car.rank = index + 1;
    });
  }

  private syncAll() {
    for (const car of this.cars) this.syncOne(car);
  }

  private syncOne(car: SimCar) {
    const pose = poseAt(this.spline, car.totalDistance, car.lane);
    car.x = pose.x;
    car.y = pose.y;
    car.angle = pose.angle;
    car.curvature = pose.curvature;
  }

  private pushTicker(text: string, kind: string, force = false) {
    if (!force && this.clock < this.ticker.until) return;
    this.ticker = { text, kind, until: this.clock + 2.3 };
  }

  private spawn(car: SimCar, kind: "flame" | "smoke" | "spray" | "debris") {
    if (this.particles.length > 150) this.particles.shift();
    const backX = car.x - Math.cos(car.angle) * 12;
    const backY = car.y - Math.sin(car.angle) * 12;
    const flame = kind === "flame";
    this.particles.push({
      x: backX + (Math.random() * 6 - 3),
      y: backY + (Math.random() * 6 - 3),
      vx: -Math.cos(car.angle) * (flame ? 40 : 18) + (Math.random() * 20 - 10),
      vy: -Math.sin(car.angle) * (flame ? 40 : 18) + (Math.random() * 20 - 10),
      life: flame ? 0.22 : kind === "debris" ? 0.7 : 0.32,
      max: flame ? 0.22 : 0.7,
      r: flame ? 3 + Math.random() * 2 : kind === "debris" ? 3 : 2.4,
      color: flame ? (Math.random() > 0.5 ? "#f97316" : "#facc15") : kind === "debris" ? "#e7e5e4" : kind === "spray" ? "rgba(186,230,253,0.7)" : "rgba(226,232,240,0.55)",
    });
  }

  private ageParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= dt;
      if (p.life <= 0) this.particles.splice(i, 1);
    }
  }
}
