import type { DecorKind, Pt, TrackDef, Zone } from "./types";

export type SplinePoint = {
  x: number;
  y: number;
  tx: number;
  ty: number;
  nx: number;
  ny: number;
  angle: number;
  curvature: number;
  signedCurvature: number;
};

export type Decor = {
  x: number;
  y: number;
  scale: number;
  kind: DecorKind;
  shade: number;
};

export type Spline = {
  points: SplinePoint[];
  totalLength: number;
  roadWidth: number;
  decorations: Decor[];
  zones: Zone[];
};

export function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

function catmull(p0: Pt, p1: Pt, p2: Pt, p3: Pt, t: number): Pt {
  const t2 = t * t;
  const t3 = t2 * t;
  return {
    x:
      0.5 *
      (2 * p1.x +
        (-p0.x + p2.x) * t +
        (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * t2 +
        (-p0.x + 3 * p1.x - 3 * p2.x + p3.x) * t3),
    y:
      0.5 *
      (2 * p1.y +
        (-p0.y + p2.y) * t +
        (2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y) * t2 +
        (-p0.y + 3 * p1.y - 3 * p2.y + p3.y) * t3),
  };
}

function hash(text: string) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619);
  return h >>> 0;
}

function mulberry32(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function buildZones(points: SplinePoint[]): Zone[] {
  const n = points.length;
  const curvs = points.map((p) => p.curvature);
  const sorted = [...curvs].sort((a, b) => a - b);
  const lowT = sorted[Math.floor(n * 0.22)] ?? 0;
  const highT = sorted[Math.floor(n * 0.8)] ?? 1;
  const zones: Zone[] = [];
  let boosts = 0;
  let jumps = 0;
  let gravels = 0;
  let oils = 0;
  let i = Math.floor(n * 0.1);
  const end = Math.floor(n * 0.88);
  while (i < end && zones.length < 8) {
    const c = points[i].curvature;
    const at = i / n;
    if (c <= lowT && (boosts < 2 || jumps < 1)) {
      const kind = boosts <= jumps ? "boost" : "jump";
      if (kind === "boost") boosts += 1;
      else jumps += 1;
      zones.push({
        id: `${kind}-${zones.length}`,
        at,
        length: kind === "boost" ? 0.04 : 0.028,
        kind,
        lane: 0,
        width: 0.95,
      });
      i += Math.floor(n * 0.14);
    } else if (c >= highT && (gravels < 2 || oils < 2)) {
      const sign = Math.sign(points[i].signedCurvature) || 1;
      if (gravels < 2) {
        gravels += 1;
        zones.push({
          id: `gravel-${zones.length}`,
          at,
          length: 0.045,
          kind: "gravel",
          lane: -sign * 0.78,
          width: 0.48,
        });
      }
      if (oils < 2) {
        oils += 1;
        zones.push({
          id: `oil-${zones.length}`,
          at: Math.min(0.9, at + 0.02),
          length: 0.03,
          kind: "oil",
          lane: sign * 0.12,
          width: 0.62,
        });
      }
      i += Math.floor(n * 0.16);
    } else {
      i += Math.floor(n * 0.04);
    }
  }
  if (!zones.some((z) => z.kind === "boost")) {
    zones.push({ id: "boost-f", at: 0.22, length: 0.04, kind: "boost", lane: 0, width: 0.95 });
  }
  if (!zones.some((z) => z.kind === "jump")) {
    zones.push({ id: "jump-f", at: 0.58, length: 0.03, kind: "jump", lane: 0, width: 0.95 });
  }
  if (!zones.some((z) => z.kind === "oil")) {
    zones.push({ id: "oil-f", at: 0.4, length: 0.03, kind: "oil", lane: 0.2, width: 0.7 });
  }
  if (!zones.some((z) => z.kind === "gravel")) {
    zones.push({ id: "gravel-f", at: 0.72, length: 0.04, kind: "gravel", lane: -0.75, width: 0.5 });
  }
  return zones;
}

function buildDecor(track: TrackDef, points: SplinePoint[], w: number, h: number, road: number): Decor[] {
  const rand = mulberry32(hash(track.id));
  const decos: Decor[] = [];
  const minDist = road * 0.92;
  const target = track.decor === "stand" ? 10 : 34;
  for (let attempt = 0; attempt < 140 && decos.length < target; attempt++) {
    const x = 16 + rand() * (w - 32);
    const y = 16 + rand() * (h - 32);
    let close = false;
    for (let i = 0; i < points.length; i += 5) {
      if (Math.hypot(x - points[i].x, y - points[i].y) < minDist) {
        close = true;
        break;
      }
    }
    if (close) continue;
    decos.push({
      x,
      y,
      scale: 0.75 + rand() * 0.5,
      kind: track.decor,
      shade: rand(),
    });
  }
  return decos;
}

export function buildSpline(track: TrackDef, width: number, height: number, samples = 640): Spline {
  const n = track.points.length;
  const scaled = track.points.map((p) => ({ x: p.x * width, y: p.y * height }));
  const raw: Pt[] = [];
  for (let i = 0; i < samples; i++) {
    const u = (i / samples) * n;
    const seg = Math.floor(u) % n;
    const localT = u - Math.floor(u);
    const p0 = scaled[(seg - 1 + n) % n];
    const p1 = scaled[seg];
    const p2 = scaled[(seg + 1) % n];
    const p3 = scaled[(seg + 2) % n];
    raw.push(catmull(p0, p1, p2, p3, localT));
  }

  const cum = [0];
  let total = 0;
  for (let i = 1; i <= samples; i++) {
    const prev = raw[i - 1];
    const curr = raw[i % samples];
    total += Math.hypot(curr.x - prev.x, curr.y - prev.y);
    cum.push(total);
  }

  const count = 560;
  const step = total / count;
  const points: SplinePoint[] = [];
  let rawIdx = 0;
  for (let i = 0; i < count; i++) {
    const target = i * step;
    while (rawIdx < samples - 1 && cum[rawIdx + 1] < target) rawIdx += 1;
    const d0 = cum[rawIdx];
    const d1 = cum[rawIdx + 1];
    const ratio = d1 > d0 ? (target - d0) / (d1 - d0) : 0;
    const a = raw[rawIdx];
    const b = raw[(rawIdx + 1) % samples];
    points.push({
      x: a.x + (b.x - a.x) * ratio,
      y: a.y + (b.y - a.y) * ratio,
      tx: 1,
      ty: 0,
      nx: 0,
      ny: 1,
      angle: 0,
      curvature: 0,
      signedCurvature: 0,
    });
  }

  for (let i = 0; i < count; i++) {
    const prev = points[(i - 2 + count) % count];
    const next = points[(i + 2) % count];
    const dx = next.x - prev.x;
    const dy = next.y - prev.y;
    const len = Math.hypot(dx, dy) || 1;
    points[i].tx = dx / len;
    points[i].ty = dy / len;
    points[i].nx = -points[i].ty;
    points[i].ny = points[i].tx;
    points[i].angle = Math.atan2(points[i].ty, points[i].tx);
  }

  for (let i = 0; i < count; i++) {
    const prev = points[(i - 8 + count) % count];
    const next = points[(i + 8) % count];
    let dAngle = next.angle - prev.angle;
    while (dAngle > Math.PI) dAngle -= Math.PI * 2;
    while (dAngle < -Math.PI) dAngle += Math.PI * 2;
    points[i].signedCurvature = dAngle;
    points[i].curvature = Math.abs(dAngle);
  }

  const roadWidth = Math.max(46, Math.min(width, height) * 0.135);
  return {
    points,
    totalLength: total,
    roadWidth,
    decorations: buildDecor(track, points, width, height, roadWidth),
    zones: buildZones(points),
  };
}

export function poseAt(spline: Spline, distance: number, lane: number) {
  const len = spline.totalLength || 1;
  const wrapped = ((distance % len) + len) % len;
  const u = (wrapped / len) * spline.points.length;
  const i0 = Math.floor(u) % spline.points.length;
  const i1 = (i0 + 1) % spline.points.length;
  const frac = u - Math.floor(u);
  const p0 = spline.points[i0];
  const p1 = spline.points[i1];
  const cx = p0.x + (p1.x - p0.x) * frac;
  const cy = p0.y + (p1.y - p0.y) * frac;
  const nx = p0.nx + (p1.nx - p0.nx) * frac;
  const ny = p0.ny + (p1.ny - p0.ny) * frac;
  const maxLat = spline.roadWidth * 0.34;
  return {
    x: cx + nx * lane * maxLat,
    y: cy + ny * lane * maxLat,
    angle: p0.angle,
    curvature: p0.curvature,
    nx,
    ny,
  };
}

export function fractionOf(distance: number, len: number) {
  if (len <= 0) return 0;
  return ((distance % len) + len) % len / len;
}
