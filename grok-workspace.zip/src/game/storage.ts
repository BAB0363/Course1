import { CARS, TRACKS } from "./data";
import { scoreRace } from "./scoring";
import type {
  Championship,
  Player,
  RaceMode,
  RaceResult,
  SaveData,
  TrackRecord,
  Trophy,
  WeatherSetting,
} from "./types";

const KEY = "pocket-gp-save-v1";

function defaultSave(): SaveData {
  return {
    version: 1,
    players: [
      { id: 1, name: "Léo", carId: 0, score: 0, wins: 0, podiums: 0 },
      { id: 2, name: "Clara", carId: 1, score: 0, wins: 0, podiums: 0 },
    ],
    nextPlayerId: 3,
    sound: true,
    mode: "gp",
    weather: "clear",
    trackId: TRACKS[0].id,
    carCount: 4,
    lapCount: 3,
    safetyCar: true,
    selectedCar: 0,
    records: {},
    championship: null,
    trophies: [],
  };
}

function isMode(v: unknown): v is RaceMode {
  return v === "gp" || v === "timetrial" || v === "elimination" || v === "teams";
}

function isWeather(v: unknown): v is WeatherSetting {
  return v === "clear" || v === "rain" || v === "fog" || v === "wind" || v === "random";
}

function sanitizePlayer(raw: unknown, fallbackId: number): Player | null {
  if (!raw || typeof raw !== "object") return null;
  const p = raw as Partial<Player>;
  if (typeof p.name !== "string" || !p.name.trim()) return null;
  const id = typeof p.id === "number" ? p.id : fallbackId;
  const carId = typeof p.carId === "number" ? Math.max(0, Math.min(CARS.length - 1, p.carId)) : 0;
  return {
    id,
    name: p.name.trim().slice(0, 14),
    carId,
    score: typeof p.score === "number" ? p.score : 0,
    wins: typeof p.wins === "number" ? p.wins : 0,
    podiums: typeof p.podiums === "number" ? p.podiums : 0,
  };
}

export function parseSave(text: string): SaveData | null {
  try {
    const raw = JSON.parse(text) as Partial<SaveData>;
    if (!raw || raw.version !== 1 || !Array.isArray(raw.players)) return null;
    const base = defaultSave();
    const players = raw.players.map((p, i) => sanitizePlayer(p, i + 1)).filter((p): p is Player => !!p);
    const records: Record<string, TrackRecord> = {};
    if (raw.records && typeof raw.records === "object") {
      for (const [id, rec] of Object.entries(raw.records)) {
        if (!rec || typeof rec.ms !== "number") continue;
        records[id] = {
          ms: rec.ms,
          carName: String(rec.carName ?? ""),
          holder: String(rec.holder ?? ""),
          date: String(rec.date ?? ""),
        };
      }
    }
    let championship: Championship | null = null;
    if (raw.championship && typeof raw.championship === "object") {
      const c = raw.championship;
      if (Array.isArray(c.trackIds) && typeof c.rounds === "number" && isMode(c.mode) && isWeather(c.weather)) {
        championship = {
          id: String(c.id ?? "champ"),
          rounds: c.rounds,
          round: typeof c.round === "number" ? c.round : 0,
          trackIds: c.trackIds.map(String),
          mode: c.mode,
          weather: c.weather,
          carCount: typeof c.carCount === "number" ? c.carCount : 4,
          lapCount: typeof c.lapCount === "number" ? c.lapCount : 3,
          safetyCar: c.safetyCar !== false,
          standings: Array.isArray(c.standings)
            ? c.standings
                .filter((s) => s && typeof s.playerId === "number")
                .map((s) => ({
                  playerId: s.playerId,
                  points: typeof s.points === "number" ? s.points : 0,
                  wins: typeof s.wins === "number" ? s.wins : 0,
                }))
            : [],
          completed: !!c.completed,
          history: Array.isArray(c.history)
            ? c.history
                .filter((h) => h && typeof h.trackId === "string")
                .map((h) => ({
                  round: typeof h.round === "number" ? h.round : 0,
                  trackId: h.trackId,
                  winner: String(h.winner ?? ""),
                }))
            : [],
        };
      }
    }
    const trophies: Trophy[] = Array.isArray(raw.trophies)
      ? raw.trophies
          .filter((t) => t && typeof t.playerName === "string")
          .slice(0, 18)
          .map((t) => ({
            id: String(t.id ?? Math.random()),
            title: String(t.title ?? "Trophée"),
            playerName: t.playerName,
            detail: String(t.detail ?? ""),
            date: String(t.date ?? ""),
          }))
      : [];
    const ids = players.map((p) => p.id);
    return {
      ...base,
      players: players.length ? players : base.players,
      nextPlayerId: Math.max(base.nextPlayerId, ...(ids.length ? ids : [2])) + 1,
      sound: raw.sound !== false,
      mode: isMode(raw.mode) ? raw.mode : base.mode,
      weather: isWeather(raw.weather) ? raw.weather : base.weather,
      trackId: typeof raw.trackId === "string" ? raw.trackId : base.trackId,
      carCount: typeof raw.carCount === "number" ? Math.min(6, Math.max(3, raw.carCount)) : 4,
      lapCount: typeof raw.lapCount === "number" ? raw.lapCount : 3,
      safetyCar: raw.safetyCar !== false,
      selectedCar: typeof raw.selectedCar === "number" ? raw.selectedCar : 0,
      records,
      championship,
      trophies,
    };
  } catch {
    return null;
  }
}

export function loadSave(): SaveData {
  try {
    const text = localStorage.getItem(KEY);
    if (!text) return defaultSave();
    return parseSave(text) ?? defaultSave();
  } catch {
    return defaultSave();
  }
}

export function persistSave(save: SaveData) {
  try {
    localStorage.setItem(KEY, JSON.stringify(save));
  } catch {
    /* private mode / quota */
  }
}

export function downloadSave(save: SaveData) {
  const blob = new Blob([JSON.stringify(save, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const day = new Date().toISOString().slice(0, 10);
  a.href = url;
  a.download = `pocket-gp-${day}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export function createChampionship(save: SaveData, rounds: number): SaveData {
  const order = TRACKS.map((t) => t.id);
  const start = Math.max(0, order.indexOf(save.trackId));
  const trackIds = Array.from({ length: rounds }, (_, i) => order[(start + i) % order.length]);
  const championship: Championship = {
    id: `${Date.now()}`,
    rounds,
    round: 0,
    trackIds,
    mode: save.mode,
    weather: save.weather,
    carCount: save.carCount,
    lapCount: save.lapCount,
    safetyCar: save.mode === "timetrial" ? false : save.safetyCar,
    standings: save.players.map((p) => ({ playerId: p.id, points: 0, wins: 0 })),
    completed: false,
    history: [],
  };
  return { ...save, championship };
}

export function applyRace(save: SaveData, result: RaceResult): SaveData {
  const scored = scoreRace(result, save.players);
  const players = save.players.map((p) => {
    const row = scored.find((s) => s.playerId === p.id);
    if (!row) return p;
    return {
      ...p,
      score: p.score + row.gained,
      wins: p.wins + (row.gained >= 3 ? 1 : 0),
      podiums: p.podiums + (row.carRank <= 3 ? 1 : 0),
    };
  });

  let records = save.records;
  if (result.mode === "timetrial") {
    const best = result.rows.find((r) => r.finishTime != null);
    if (best?.finishTime != null) {
      const ms = Math.round(best.finishTime * 1000);
      const prev = records[result.trackId];
      if (!prev || ms < prev.ms) {
        const holder =
          save.players
            .filter((p) => p.carId === best.id)
            .map((p) => p.name)
            .join(", ") || best.short;
        records = {
          ...records,
          [result.trackId]: { ms, carName: best.name, holder, date: new Date().toISOString() },
        };
      }
    }
  }

  let championship = save.championship
    ? {
        ...save.championship,
        standings: save.championship.standings.map((s) => ({ ...s })),
        history: [...save.championship.history],
      }
    : null;
  let trophies = save.trophies;

  if (championship && !championship.completed) {
    for (const row of scored) {
      let standing = championship.standings.find((s) => s.playerId === row.playerId);
      if (!standing) {
        standing = { playerId: row.playerId, points: 0, wins: 0 };
        championship.standings.push(standing);
      }
      standing.points += row.gained;
      if (row.gained >= 3) standing.wins += 1;
    }
    championship.history.push({
      round: championship.round + 1,
      trackId: result.trackId,
      winner: result.rows[0]?.name ?? "—",
    });
    championship.round += 1;
    if (championship.round >= championship.rounds) {
      championship.completed = true;
      const board = [...championship.standings].sort((a, b) => b.points - a.points || b.wins - a.wins);
      const titles = ["Champion", "Vice-champion", "Troisième marche"];
      const awarded: Trophy[] = board.slice(0, 3).map((row, i) => ({
        id: `${championship!.id}-${i}`,
        title: titles[i] ?? "Podium",
        playerName: players.find((p) => p.id === row.playerId)?.name ?? "Joueur",
        detail: `${row.points} pts sur ${championship!.rounds} manches`,
        date: new Date().toISOString(),
      }));
      trophies = [...awarded, ...trophies].slice(0, 18);
    }
  }

  return { ...save, players, records, championship, trophies };
}

export function zeroScores(save: SaveData): SaveData {
  return {
    ...save,
    players: save.players.map((p) => ({ ...p, score: 0, wins: 0, podiums: 0 })),
    championship: null,
  };
}
