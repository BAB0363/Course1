let ctx: AudioContext | null = null;
let enabled = true;

export function setSoundEnabled(on: boolean) {
  enabled = on;
}

export function soundEnabled() {
  return enabled;
}

export function unlockAudio() {
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AC) return;
  if (!ctx) ctx = new AC();
  if (ctx.state === "suspended") void ctx.resume();
}

function tone(freq: number, type: OscillatorType, duration: number, volume: number, slide: number | null = null) {
  if (!enabled) return;
  try {
    unlockAudio();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    if (slide) osc.frequency.exponentialRampToValueAtTime(slide, ctx.currentTime + duration);
    gain.gain.setValueAtTime(volume, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch {
    /* restricted autoplay */
  }
}

export function playBlip(freq = 520) {
  tone(freq, "sine", 0.07, 0.08);
}

export function playCountdown(go = false) {
  if (go) tone(880, "square", 0.35, 0.14, 1174);
  else tone(440, "square", 0.16, 0.11);
}

export function playBoost() {
  tone(220, "sawtooth", 0.2, 0.06, 520);
}

export function playJump() {
  tone(180, "triangle", 0.18, 0.08, 640);
}

export function playElim() {
  tone(320, "sawtooth", 0.22, 0.08, 90);
}

export function playSafety() {
  tone(196, "square", 0.18, 0.07);
  window.setTimeout(() => tone(164, "square", 0.22, 0.07), 160);
}

export function playFanfare() {
  if (!enabled) return;
  [523.25, 659.25, 783.99, 1046.5].forEach((n, i) => {
    window.setTimeout(() => tone(n, "triangle", 0.22, 0.14), i * 110);
  });
}

export function playEvent(name: string) {
  if (name === "boost") playBoost();
  else if (name === "jump") playJump();
  else if (name === "elim") playElim();
  else if (name === "sc") playSafety();
  else if (name === "win") playFanfare();
  else if (name === "restart") tone(660, "triangle", 0.12, 0.08, 880);
  else if (name === "land") tone(110, "sine", 0.08, 0.05);
}
