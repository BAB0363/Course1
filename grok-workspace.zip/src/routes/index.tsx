import { createFileRoute } from "@tanstack/react-router";
import { PocketGP } from "@/components/pocket-gp/PocketGP";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <PocketGP />;
}
